import crypto from 'node:crypto';
import mammoth from 'mammoth';
import { PDFParse } from 'pdf-parse';
import { ApiError } from './authMiddleware.ts';

export interface ParsedChunkDraft {
  content: string;
  keywords: string[];
  pageNumber: number;
  sectionTitle: string;
}

export interface ParsedDocumentResult {
  extractedText: string;
  contentHash: string;
  chunks: ParsedChunkDraft[];
  sourceType: 'pdf' | 'docx' | 'txt' | 'csv' | 'url';
}

const STOP_WORDS = new Set([
  'the', 'and', 'for', 'with', 'that', 'this', 'from', 'your', 'you', 'are', 'was',
  'were', 'will', 'have', 'has', 'had', 'not', 'but', 'can', 'all', 'any', 'our',
  'out', 'per', 'use', 'using', 'into', 'than', 'then', 'when', 'what', 'which',
  'who', 'how', 'why', 'where', 'there', 'their', 'they', 'them', 'been', 'being',
  'more', 'most', 'only', 'also', 'such', 'about', 'after', 'before', 'each',
]);

export function extractKeywords(text: string, maxKeywords = 16): string[] {
  const counts = new Map<string, number>();
  const words = text
    .toLowerCase()
    .replace(/[^a-z0-9%$£€₦\s-]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length >= 3 && !STOP_WORDS.has(w));

  for (const word of words) {
    counts.set(word, (counts.get(word) ?? 0) + 1);
  }

  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, maxKeywords)
    .map(([word]) => word);
}

export function chunkText(
  rawText: string,
  defaultSectionTitle: string,
  maxChunkChars = 1600,
): ParsedChunkDraft[] {
  const cleaned = rawText
    .replace(/\r\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  if (!cleaned) {
    return [];
  }

  const paragraphs = cleaned.split(/\n\n+/);
  const chunks: ParsedChunkDraft[] = [];
  let buffer = '';
  let currentSection = defaultSectionTitle.slice(0, 180) || 'General';
  let pageCounter = 1;

  const flush = () => {
    const trimmed = buffer.trim();
    if (!trimmed) return;
    chunks.push({
      content: trimmed.slice(0, 5800),
      keywords: extractKeywords(trimmed),
      pageNumber: pageCounter,
      sectionTitle: currentSection,
    });
    if (chunks.length % 3 === 0) {
      pageCounter += 1;
    }
    buffer = '';
  };

  for (const para of paragraphs) {
    const p = para.trim();
    if (!p) continue;

    // Detect heading-like lines
    if (p.length <= 90 && !p.endsWith('.') && /^[A-Z0-9#]/.test(p)) {
      if (buffer.length > 350) {
        flush();
      }
      currentSection = p.replace(/^#+\s*/, '').slice(0, 180);
    }

    if (p.length > maxChunkChars) {
      flush();
      // Split oversized paragraph by sentence or fixed slice
      for (let idx = 0; idx < p.length; idx += maxChunkChars) {
        const slice = p.slice(idx, idx + maxChunkChars).trim();
        if (slice) {
          chunks.push({
            content: slice,
            keywords: extractKeywords(slice),
            pageNumber: pageCounter,
            sectionTitle: currentSection,
          });
        }
      }
      continue;
    }

    if ((buffer + '\n\n' + p).length > maxChunkChars) {
      flush();
    }

    buffer = buffer ? `${buffer}\n\n${p}` : p;
  }

  flush();
  return chunks.slice(0, 80);
}

export function computeContentHash(text: string): string {
  return crypto.createHash('sha256').update(text).digest('hex').slice(0, 32);
}

export async function parseUploadedDocument(
  fileBuffer: Buffer,
  fileName: string,
  mimeType: string,
  fallbackTitle: string,
): Promise<ParsedDocumentResult> {
  const lower = fileName.toLowerCase();
  let extractedText = '';
  let sourceType: ParsedDocumentResult['sourceType'] = 'txt';

  if (lower.endsWith('.pdf') || mimeType === 'application/pdf') {
    sourceType = 'pdf';
    const parser = new PDFParse({ data: fileBuffer });
    try {
      const result = await parser.getText();
      extractedText = (result.text ?? '').trim();
    } finally {
      await parser.destroy().catch(() => {});
    }
  } else if (
    lower.endsWith('.docx') ||
    mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ) {
    sourceType = 'docx';
    const result = await mammoth.extractRawText({ buffer: fileBuffer });
    extractedText = (result.value ?? '').trim();
  } else if (lower.endsWith('.csv') || mimeType === 'text/csv') {
    sourceType = 'csv';
    extractedText = fileBuffer.toString('utf-8').trim();
  } else if (
    lower.endsWith('.txt') ||
    lower.endsWith('.md') ||
    mimeType.startsWith('text/')
  ) {
    sourceType = 'txt';
    extractedText = fileBuffer.toString('utf-8').trim();
  } else {
    throw new ApiError(
      400,
      'UNSUPPORTED_FILE',
      'Supported formats are PDF, DOCX, TXT, MD, and CSV.',
    );
  }

  if (!extractedText) {
    throw new ApiError(
      422,
      'EMPTY_DOCUMENT',
      'No readable text could be extracted from this file. For scanned PDFs, export searchable text or paste policy text directly.',
    );
  }

  const chunks = chunkText(extractedText, fallbackTitle || fileName);
  return {
    extractedText,
    contentHash: computeContentHash(extractedText),
    chunks,
    sourceType,
  };
}

function stripHtmlToReadableText(html: string): { title: string; text: string } {
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = titleMatch ? titleMatch[1].replace(/\s+/g, ' ').trim() : '';

  const withoutNoise = html
    .replace(/<script[\s\S]*?<\/script>/gi, '\n')
    .replace(/<style[\s\S]*?<\/style>/gi, '\n')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, '\n')
    .replace(/<svg[\s\S]*?<\/svg>/gi, '\n');

  const blockBreaks = withoutNoise
    .replace(/<\/(h1|h2|h3|h4|p|li|tr|div|section|article)>/gi, '\n\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();

  return { title, text: blockBreaks };
}

export async function importFromUrl(
  rawUrl: string,
  fallbackTitle: string,
): Promise<ParsedDocumentResult & { resolvedTitle: string }> {
  let parsedUrl: URL;
  try {
    parsedUrl = new URL(rawUrl.trim());
  } catch {
    throw new ApiError(400, 'INVALID_URL', 'Please enter a valid http or https URL.');
  }

  if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
    throw new ApiError(400, 'INVALID_URL', 'Only http and https URLs are supported.');
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  let html = '';
  try {
    const response = await fetch(parsedUrl.toString(), {
      signal: controller.signal,
      headers: {
        'User-Agent': 'ThaurusGuruSalesOS/1.0 (+https://thaurusguru.com)',
        Accept: 'text/html, text/plain, application/xhtml+xml',
      },
    });
    if (!response.ok) {
      throw new ApiError(
        502,
        'URL_FETCH_FAILED',
        `Remote source returned HTTP ${response.status}. You may copy and upload the page text directly instead.`,
      );
    }
    html = await response.text();
  } catch (err) {
    if (err instanceof ApiError) throw err;
    throw new ApiError(
      502,
      'URL_FETCH_FAILED',
      'Unable to fetch the requested URL within 15s. Please verify network access or upload a document file directly.',
    );
  } finally {
    clearTimeout(timeout);
  }

  const { title, text } = stripHtmlToReadableText(html);
  if (!text || text.length < 40) {
    throw new ApiError(
      422,
      'URL_EMPTY_CONTENT',
      'The URL returned minimal readable text (it may require client-side rendering). Upload a PDF/DOCX/TXT snapshot for reliable indexing.',
    );
  }

  const resolvedTitle = fallbackTitle.trim() || title || parsedUrl.hostname;
  const chunks = chunkText(text, resolvedTitle);
  return {
    extractedText: text,
    contentHash: computeContentHash(text),
    chunks,
    sourceType: 'url',
    resolvedTitle,
  };
}
