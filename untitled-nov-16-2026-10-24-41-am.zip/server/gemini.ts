import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import { ApiError } from './authMiddleware.ts';

export type ThinkingMode = 'auto' | 'fast' | 'deep';
export type AllowedModel = 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite';

export interface KnowledgeContextChunk {
  sourceTitle: string;
  category: string;
  documentVersion: number;
  sectionTitle: string;
  content: string;
}

export interface MemoryContextItem {
  memoryType: string;
  memoryContent: string;
  confidence: string;
}

export interface FeedbackContextSummary {
  helpfulCount: number;
  negativeCount: number;
  topIssues: string[];
  recentComments: string[];
}

export interface StrategyContextItem {
  version: number;
  title: string;
  proposedChange: string;
}

export interface IntelligenceContextPayload {
  model?: AllowedModel;
  thinkingMode?: ThinkingMode;
  communicationStyle?: string;
  knowledgeChunks?: KnowledgeContextChunk[];
  userMemories?: MemoryContextItem[];
  feedbackSummary?: FeedbackContextSummary;
  activeStrategies?: StrategyContextItem[];
  prospectProfile?: {
    displayName: string;
    tradingExperience?: string;
    preferredChallenge?: string;
    preferredAccountSize?: string;
    primaryConcern?: string;
    objections?: string[];
    verifiedNotes?: string;
  };
}

function getGenAIClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new ApiError(
      500,
      'MISSING_GEMINI_KEY',
      'GEMINI_API_KEY is not configured in server secrets.',
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export function resolveModelAndThinking(
  requestedMode: ThinkingMode = 'auto',
  requestedModel: AllowedModel = 'gemini-4-hydrogen',
  promptText = '',
  forceDeep = false,
): {
  model: AllowedModel;
  resolvedMode: 'fast' | 'deep';
  thinkingLevel: ThinkingLevel;
} {
  const safeModel: AllowedModel =
    requestedModel === 'gemini-3.1-flash-lite' ? 'gemini-3.1-flash-lite' : 'gemini-4-hydrogen';

  let resolvedMode: 'fast' | 'deep' = 'fast';
  if (forceDeep || requestedMode === 'deep') {
    resolvedMode = 'deep';
  } else if (requestedMode === 'fast') {
    resolvedMode = 'fast';
  } else {
    // Auto triage based on complexity signals
    const lower = promptText.toLowerCase();
    const deepSignals = [
      'compare', 'comparison', 'strategy', 'analyse', 'analyze', 'review', 'policy',
      'terms', 'drawdown', 'payout rule', 'refund', 'closing', 'objection', 'audit',
      'why should i trust', 'full conversation', 'transcript',
    ];
    const isComplex =
      promptText.length > 320 || deepSignals.some((signal) => lower.includes(signal));
    resolvedMode = isComplex ? 'deep' : 'fast';
  }

  if (safeModel === 'gemini-3.1-flash-lite') {
    return {
      model: safeModel,
      resolvedMode,
      thinkingLevel: resolvedMode === 'deep' ? ThinkingLevel.MEDIUM : ThinkingLevel.MINIMAL,
    };
  }

  return {
    model: 'gemini-4-hydrogen',
    resolvedMode,
    thinkingLevel: resolvedMode === 'deep' ? ThinkingLevel.HIGH : ThinkingLevel.LOW,
  };
}

export function buildSystemInstruction(
  ctx: IntelligenceContextPayload,
  taskDirective: string,
): string {
  const knowledgeBlock =
    ctx.knowledgeChunks && ctx.knowledgeChunks.length > 0
      ? ctx.knowledgeChunks
          .map(
            (c, i) =>
              `[K${i + 1}] Source: "${c.sourceTitle}" (v${c.documentVersion}) | Category: ${c.category} | Section: ${c.sectionTitle}\n${c.content}`,
          )
          .join('\n\n')
      : 'No verified company knowledge chunks matched this query in the Knowledge Base yet.';

  const memoryBlock =
    ctx.userMemories && ctx.userMemories.length > 0
      ? ctx.userMemories
          .map((m) => `- (${m.memoryType}, confidence: ${m.confidence}) ${m.memoryContent}`)
          .join('\n')
      : 'No personal executive memory entries active yet.';

  const feedbackBlock = ctx.feedbackSummary
    ? `Positive ratings: ${ctx.feedbackSummary.helpfulCount}, Negative ratings: ${ctx.feedbackSummary.negativeCount}. Recurring critiques to avoid: ${ctx.feedbackSummary.topIssues.join(', ') || 'None recorded'}. Recent notes: ${ctx.feedbackSummary.recentComments.slice(0, 3).join(' | ') || 'None'}.`
    : 'No accumulated feedback constraints yet.';

  const strategyBlock =
    ctx.activeStrategies && ctx.activeStrategies.length > 0
      ? ctx.activeStrategies
          .map((s) => `- [v${s.version}] ${s.title}: ${s.proposedChange}`)
          .join('\n')
      : 'Baseline instruction v1 active.';

  const prospectBlock = ctx.prospectProfile
    ? `Prospect: ${ctx.prospectProfile.displayName}
Experience: ${ctx.prospectProfile.tradingExperience || 'Unknown'}
Preferred Challenge: ${ctx.prospectProfile.preferredChallenge || 'Unspecified'} (${ctx.prospectProfile.preferredAccountSize || 'Size unspecified'})
Primary Concern: ${ctx.prospectProfile.primaryConcern || 'None recorded'}
Known Objections: ${(ctx.prospectProfile.objections ?? []).join('; ') || 'None'}
Verified Notes: ${ctx.prospectProfile.verifiedNotes || 'None'}`
    : 'No specific prospect profile linked.';

  return `You are THAURUS GURU INTELLIGENCE — the dedicated AI Sales Partner for a Thaurus Guru Sales Executive (proprietary trading / prop firm sector).

IDENTITY & CAPABILITIES:
You combine: Senior Sales Strategist, Prop Trading Product Specialist, Fintech Consultant, Customer Psychology Analyst, Conversational Sales Expert, Cold-Calling Coach, Objection-Handling Specialist, Closing Consultant, and Sales Performance Analyst.
Your personality: Intelligent, alert, commercially aware, inquisitive, confident, adaptive, persuasive, analytical, and conversational. Use natural, refined Nigerian English phrasing where culturally appropriate without sounding forced, generic, or robotic.
Guiding Sales Philosophy: UNDERSTAND -> DISCOVER -> CONNECT -> BUILD TRUST -> PRESENT VALUE -> RESOLVE CONCERNS -> CLOSE.

STRICT FACTUAL & KNOWLEDGE GOVERNANCE RULES:
1. NEVER invent Thaurus Guru pricing, drawdown percentages, profit split numbers, payout timelines, challenge rules, or refund terms that are not explicitly present in the VERIFIED KNOWLEDGE CHUNKS below.
2. If the executive asks a product/policy question and the Verified Knowledge Chunks do not cover it (or contain conflicting versions), explicitly state what is missing or conflicting and advise logging a Knowledge Gap.
3. Cite supporting sources using exact source titles when stating product facts (e.g., [Source: Title v1]).
4. Never fabricate artificial urgency or pressure tactics.
5. Never expose private internal reasoning or claim your model weights were fine-tuned.

COMMUNICATION PREFERENCE: ${ctx.communicationStyle || 'Natural'}

LAYER 5 — APPROVED STRATEGY INSTRUCTIONS:
${strategyBlock}

LAYER 2 — FEEDBACK LEARNING CONSTRAINTS:
${feedbackBlock}

LAYER 1 — EXECUTIVE PERSISTENT MEMORY:
${memoryBlock}

LINKED PROSPECT CONTEXT:
${prospectBlock}

VERIFIED COMPANY KNOWLEDGE CHUNKS (RAG):
${knowledgeBlock}

TASK DIRECTIVE:
${taskDirective}`;
}

export async function streamLiveAssistant(params: {
  prompt: string;
  channel: string;
  style: string;
  responseOnly: boolean;
  history: Array<{ role: 'user' | 'assistant'; content: string }>;
  imageAttachment?: { mimeType: string; dataBase64: string };
  context: IntelligenceContextPayload;
  onChunk: (text: string) => void;
}): Promise<{
  fullText: string;
  resolvedMode: 'fast' | 'deep';
  tokenUsage: number;
  latencyMs: number;
}> {
  const ai = getGenAIClient();
  const started = Date.now();
  const { model, resolvedMode, thinkingLevel } = resolveModelAndThinking(
    params.context.thinkingMode ?? 'auto',
    params.context.model ?? 'gemini-4-hydrogen',
    params.prompt,
  );

  const formatInstruction = params.responseOnly
    ? `Return ONLY the exact ready-to-send response message tailored for ${params.channel} in a ${params.style} tone. Do not include labels, preambles, or explanations.`
    : resolvedMode === 'fast'
      ? `FAST LIVE RESPONSE MODE (${params.channel}, tone: ${params.style}).
Keep it crisp and immediately usable mid-conversation. Use this exact structure:
BEST RESPONSE:
<exact words to send or say>

WHY IT WORKS:
<1-2 concise sentences>

NEXT MOVE:
<one sharp follow-up question or next action>`
      : `DEEP STRATEGIC RESPONSE MODE (${params.channel}, tone: ${params.style}).
Analyse the prospect's real concern, apply verified Thaurus Guru knowledge, and respond with this exact structure:
BEST RESPONSE:
<exact words to send or say>

WHY IT WORKS:
<concise strategic rationale linking prospect psychology, verified evidence, and sales stage>

NEXT MOVE:
<recommended next question or action to advance toward conversion>`;

  const systemInstruction = buildSystemInstruction(params.context, formatInstruction);

  const historyLines = params.history
    .slice(-10)
    .map((h) => `${h.role === 'user' ? 'Executive' : 'Thaurus Guru Intelligence'}: ${h.content}`)
    .join('\n\n');

  const combinedText = historyLines
    ? `PREVIOUS CONVERSATION CONTEXT:\n${historyLines}\n\nCURRENT EXECUTIVE INPUT:\n${params.prompt}`
    : params.prompt;

  const contents = params.imageAttachment
    ? {
        parts: [
          {
            inlineData: {
              mimeType: params.imageAttachment.mimeType,
              data: params.imageAttachment.dataBase64,
            },
          },
          { text: combinedText },
        ],
      }
    : combinedText;

  const stream = await ai.models.generateContentStream({
    model,
    contents,
    config: {
      systemInstruction,
      thinkingConfig: { thinkingLevel },
    },
  });

  let fullText = '';
  let tokenUsage = 0;

  for await (const chunk of stream) {
    if (chunk.text) {
      fullText += chunk.text;
      params.onChunk(chunk.text);
    }
    if (chunk.usageMetadata?.totalTokenCount) {
      tokenUsage = chunk.usageMetadata.totalTokenCount;
    }
  }

  return {
    fullText,
    resolvedMode,
    tokenUsage,
    latencyMs: Date.now() - started,
  };
}

export async function generateStructuredJson<T>(params: {
  prompt: string;
  taskDirective: string;
  schema: Record<string, unknown>;
  context: IntelligenceContextPayload;
  forceDeep?: boolean;
}): Promise<{
  data: T;
  resolvedMode: 'fast' | 'deep';
  tokenUsage: number;
  latencyMs: number;
}> {
  const ai = getGenAIClient();
  const started = Date.now();
  const { model, resolvedMode, thinkingLevel } = resolveModelAndThinking(
    params.context.thinkingMode ?? 'auto',
    params.context.model ?? 'gemini-4-hydrogen',
    params.prompt,
    params.forceDeep,
  );

  const response = await ai.models.generateContent({
    model,
    contents: params.prompt,
    config: {
      systemInstruction: buildSystemInstruction(params.context, params.taskDirective),
      thinkingConfig: { thinkingLevel },
      responseMimeType: 'application/json',
      responseSchema: params.schema,
    },
  });

  const raw = (response.text ?? '{}').trim();
  let parsed: T;
  try {
    parsed = JSON.parse(raw) as T;
  } catch {
    throw new ApiError(502, 'INVALID_AI_JSON', 'AI returned malformed structured output.');
  }

  return {
    data: parsed,
    resolvedMode,
    tokenUsage: response.usageMetadata?.totalTokenCount ?? 0,
    latencyMs: Date.now() - started,
  };
}

export const OBJECTION_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    surfaceObjection: { type: Type.STRING },
    underlyingConcern: { type: Type.STRING },
    prospectMotivation: { type: Type.STRING },
    recommendedResponse: { type: Type.STRING },
    supportingEvidence: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
    },
    followUpQuestion: { type: Type.STRING },
    suggestedNextStep: { type: Type.STRING },
    alternativeResponses: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          style: { type: Type.STRING },
          response: { type: Type.STRING },
        },
        required: ['style', 'response'],
      },
    },
    missingKnowledgeGap: { type: Type.STRING },
  },
  required: [
    'surfaceObjection',
    'underlyingConcern',
    'prospectMotivation',
    'recommendedResponse',
    'supportingEvidence',
    'followUpQuestion',
    'suggestedNextStep',
    'alternativeResponses',
    'missingKnowledgeGap',
  ],
};

export const CLOSING_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    readinessScore: { type: Type.INTEGER },
    readinessLabel: { type: Type.STRING },
    buyingSignals: { type: Type.ARRAY, items: { type: Type.STRING } },
    remainingConcerns: { type: Type.ARRAY, items: { type: Type.STRING } },
    purchaseMotivation: { type: Type.STRING },
    productSuitability: { type: Type.STRING },
    genuineUrgency: { type: Type.STRING },
    recommendedCloseType: { type: Type.STRING },
    closeScript: { type: Type.STRING },
    rationale: { type: Type.STRING },
    followUpFallback: { type: Type.STRING },
  },
  required: [
    'readinessScore',
    'readinessLabel',
    'buyingSignals',
    'remainingConcerns',
    'purchaseMotivation',
    'productSuitability',
    'genuineUrgency',
    'recommendedCloseType',
    'closeScript',
    'rationale',
    'followUpFallback',
  ],
};

export const COLD_CALL_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    openingLines: { type: Type.ARRAY, items: { type: Type.STRING } },
    naturalIntroduction: { type: Type.STRING },
    attentionQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
    discoveryQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
    productPositioning: { type: Type.STRING },
    conversationalTransitions: { type: Type.ARRAY, items: { type: Type.STRING } },
    objectionPivots: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          objection: { type: Type.STRING },
          pivot: { type: Type.STRING },
        },
        required: ['objection', 'pivot'],
      },
    },
    closingQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
    followUpStrategy: { type: Type.STRING },
  },
  required: [
    'openingLines',
    'naturalIntroduction',
    'attentionQuestions',
    'discoveryQuestions',
    'productPositioning',
    'conversationalTransitions',
    'objectionPivots',
    'closingQuestions',
    'followUpStrategy',
  ],
};

export const PRODUCT_QA_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    answer: { type: Type.STRING },
    verifiedClaims: { type: Type.ARRAY, items: { type: Type.STRING } },
    sourceCitations: { type: Type.ARRAY, items: { type: Type.STRING } },
    detectedConflicts: { type: Type.ARRAY, items: { type: Type.STRING } },
    missingInfoGaps: { type: Type.ARRAY, items: { type: Type.STRING } },
    suggestedKnowledgeGapTitle: { type: Type.STRING },
  },
  required: [
    'answer',
    'verifiedClaims',
    'sourceCitations',
    'detectedConflicts',
    'missingInfoGaps',
    'suggestedKnowledgeGapTitle',
  ],
};

export const PROSPECT_ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    tradingExperience: {
      type: Type.OBJECT,
      properties: {
        assessment: { type: Type.STRING },
        confidence: { type: Type.STRING },
        evidence: { type: Type.STRING },
      },
      required: ['assessment', 'confidence', 'evidence'],
    },
    communicationStyle: {
      type: Type.OBJECT,
      properties: {
        assessment: { type: Type.STRING },
        confidence: { type: Type.STRING },
      },
      required: ['assessment', 'confidence'],
    },
    mainMotivation: {
      type: Type.OBJECT,
      properties: {
        assessment: { type: Type.STRING },
        confidence: { type: Type.STRING },
      },
      required: ['assessment', 'confidence'],
    },
    mainObjection: {
      type: Type.OBJECT,
      properties: {
        assessment: { type: Type.STRING },
        confidence: { type: Type.STRING },
      },
      required: ['assessment', 'confidence'],
    },
    trustLevel: {
      type: Type.OBJECT,
      properties: {
        level: { type: Type.STRING },
        confidence: { type: Type.STRING },
        rationale: { type: Type.STRING },
      },
      required: ['level', 'confidence', 'rationale'],
    },
    purchaseInterest: {
      type: Type.OBJECT,
      properties: {
        level: { type: Type.STRING },
        confidence: { type: Type.STRING },
      },
      required: ['level', 'confidence'],
    },
    buyingSignals: { type: Type.ARRAY, items: { type: Type.STRING } },
    unansweredQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
    missedOpportunities: { type: Type.ARRAY, items: { type: Type.STRING } },
    recommendedNextResponse: { type: Type.STRING },
    suggestedClosingStrategy: { type: Type.STRING },
    memoryExtractionSuggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: [
    'tradingExperience',
    'communicationStyle',
    'mainMotivation',
    'mainObjection',
    'trustLevel',
    'purchaseInterest',
    'buyingSignals',
    'unansweredQuestions',
    'missedOpportunities',
    'recommendedNextResponse',
    'suggestedClosingStrategy',
    'memoryExtractionSuggestions',
  ],
};

export const SIMULATION_SCORE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    categoryScores: {
      type: Type.OBJECT,
      properties: {
        opening: { type: Type.NUMBER },
        discovery: { type: Type.NUMBER },
        listening: { type: Type.NUMBER },
        engagement: { type: Type.NUMBER },
        productKnowledge: { type: Type.NUMBER },
        trustBuilding: { type: Type.NUMBER },
        objectionHandling: { type: Type.NUMBER },
        persuasion: { type: Type.NUMBER },
        closing: { type: Type.NUMBER },
      },
      required: [
        'opening',
        'discovery',
        'listening',
        'engagement',
        'productKnowledge',
        'trustBuilding',
        'objectionHandling',
        'persuasion',
        'closing',
      ],
    },
    overallScore: { type: Type.NUMBER },
    strongestArea: { type: Type.STRING },
    biggestMissedOpportunity: { type: Type.STRING },
    betterAlternativeResponse: { type: Type.STRING },
    measurableImprovementTarget: { type: Type.STRING },
    detailedFeedback: { type: Type.STRING },
  },
  required: [
    'categoryScores',
    'overallScore',
    'strongestArea',
    'biggestMissedOpportunity',
    'betterAlternativeResponse',
    'measurableImprovementTarget',
    'detailedFeedback',
  ],
};

export const STRATEGY_PROPOSAL_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING },
    description: { type: Type.STRING },
    evidenceSummary: { type: Type.STRING },
    proposedChange: { type: Type.STRING },
    correlationVsCausationNote: { type: Type.STRING },
    recommendedKnowledgeGaps: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: [
    'title',
    'description',
    'evidenceSummary',
    'proposedChange',
    'correlationVsCausationNote',
    'recommendedKnowledgeGaps',
  ],
};

export async function generateSimulationTurn(params: {
  prospectType: string;
  difficulty: string;
  scenarioNotes?: string;
  transcript: Array<{ speaker: 'executive' | 'prospect'; text: string }>;
  context: IntelligenceContextPayload;
}): Promise<{ reply: string; tokenUsage: number; latencyMs: number }> {
  const ai = getGenAIClient();
  const started = Date.now();
  const model: AllowedModel = 'gemini-4-hydrogen';

  const systemInstruction = `You are roleplaying a realistic PROSPECT evaluating Thaurus Guru (a prop trading firm).
The human user is a Thaurus Guru Sales Executive.

PROSPECT ARCHETYPE: ${params.prospectType}
DIFFICULTY LEVEL: ${params.difficulty}
${params.scenarioNotes ? `SCENARIO CONTEXT: ${params.scenarioNotes}` : ''}

ROLEPLAY RULES (CRITICAL):
1. Do NOT be excessively cooperative or give away an easy sale.
2. Stay strictly in character as a real trader/prospect with realistic Nigerian/global prop-trading awareness.
3. Ask difficult, specific questions; challenge vague claims; demand clear evidence; raise realistic objections; change direction naturally; and reveal your true budget/motivation gradually only when the executive earns trust through discovery.
4. Respond with ONE natural conversational turn at a time (2-5 sentences). Never output coaching notes, meta commentary, or break character.
5. Difficulty scaling:
   - Beginner: Curious but hesitant, raises 1-2 common concerns.
   - Intermediate: Compares prop firms, checks drawdown/payout rules carefully.
   - Advanced: Sceptical, tests consistency and credibility, calls out scripted sales talk.
   - Expert: Tough, time-pressed or burned before, pushes hard on hidden rules, slippage, payout proof, and value vs price.`;

  const historyText =
    params.transcript.length === 0
      ? 'The executive is starting the conversation or waiting for your opening response as the prospect. Give a realistic initial prospect message or greeting/challenge fitting your persona.'
      : params.transcript
          .map((t) => `${t.speaker === 'executive' ? 'Sales Executive' : 'Prospect (You)'}: ${t.text}`)
          .join('\n\n') + '\n\nRespond next as Prospect (You):';

  const response = await ai.models.generateContent({
    model,
    contents: historyText,
    config: {
      systemInstruction,
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
    },
  });

  return {
    reply: (response.text ?? '').trim(),
    tokenUsage: response.usageMetadata?.totalTokenCount ?? 0,
    latencyMs: Date.now() - started,
  };
}

export const PROSPECT_EXTRACTION_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    displayName: { type: Type.STRING },
    contactDetails: { type: Type.STRING },
    tradingExperience: { type: Type.STRING },
    previousPropFirm: { type: Type.STRING },
    preferredChallenge: { type: Type.STRING },
    preferredAccountSize: { type: Type.STRING },
    primaryConcern: { type: Type.STRING },
    objections: { type: Type.ARRAY, items: { type: Type.STRING } },
    buyingSignals: { type: Type.ARRAY, items: { type: Type.STRING } },
    suggestedStatus: {
      type: Type.STRING,
      enum: ['new', 'contacted', 'qualified', 'follow_up', 'converted', 'declined'],
    },
    suggestedFollowUpDays: { type: Type.INTEGER },
    verifiedNotes: { type: Type.STRING },
    aiObservations: { type: Type.STRING },
  },
  required: [
    'displayName',
    'contactDetails',
    'tradingExperience',
    'previousPropFirm',
    'preferredChallenge',
    'preferredAccountSize',
    'primaryConcern',
    'objections',
    'buyingSignals',
    'suggestedStatus',
    'suggestedFollowUpDays',
    'verifiedNotes',
    'aiObservations',
  ],
};

function normalizeAudioMimeType(rawMime: string): string {
  const base = rawMime.split(';')[0].trim().toLowerCase();
  if (
    base === 'audio/webm' ||
    base === 'audio/mp4' ||
    base === 'audio/mpeg' ||
    base === 'audio/mp3' ||
    base === 'audio/wav' ||
    base === 'audio/ogg' ||
    base === 'audio/aac' ||
    base === 'audio/flac' ||
    base === 'audio/x-m4a'
  ) {
    return base === 'audio/x-m4a' ? 'audio/mp4' : base;
  }
  return 'audio/webm';
}

export async function transcribeAudio(params: {
  audioBuffer: Buffer;
  mimeType: string;
  contextHint?: string;
}): Promise<{ transcript: string; latencyMs: number }> {
  const ai = getGenAIClient();
  const started = Date.now();
  const safeMime = normalizeAudioMimeType(params.mimeType);

  const audioPart = {
    inlineData: {
      mimeType: safeMime,
      data: params.audioBuffer.toString('base64'),
    },
  };

  const promptText = params.contextHint
    ? `Transcribe this spoken sales audio accurately. Preserve proprietary trading terminology (such as Thaurus Guru, drawdown, evaluation, 2-step, profit split, payout) and Nigerian/international names naturally. Context: ${params.contextHint}. Return ONLY the clean spoken transcript text with no extra labels or commentary.`
    : 'Transcribe this spoken sales audio accurately. Preserve proprietary trading terminology (such as Thaurus Guru, drawdown, evaluation, 2-step, profit split, payout) and Nigerian/international names naturally. Return ONLY the clean spoken transcript text with no extra labels or commentary.';

  const response = await ai.models.generateContent({
    model: 'gemini-3.5-transcribe',
    contents: {
      parts: [audioPart, { text: promptText }],
    },
  });

  return {
    transcript: (response.text ?? '').trim(),
    latencyMs: Date.now() - started,
  };
}

