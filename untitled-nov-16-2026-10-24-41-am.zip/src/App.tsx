import React from 'react';
import { AuthGate } from './components/AuthGate';
import { Layout } from './components/Layout';
import { OfflineIndicator } from './components/PWAInstallButton';
import { ClosingIntelligenceModule } from './components/modules/ClosingIntelligenceModule';
import { ColdCallStudioModule } from './components/modules/ColdCallStudioModule';
import { ConversationHistoryModule } from './components/modules/ConversationHistoryModule';
import { KnowledgeBaseModule } from './components/modules/KnowledgeBaseModule';
import { LearningCentreModule } from './components/modules/LearningCentreModule';
import { LiveSalesAssistantModule } from './components/modules/LiveSalesAssistantModule';
import { ObjectionIntelligenceModule } from './components/modules/ObjectionIntelligenceModule';
import { OverviewModule } from './components/modules/OverviewModule';
import { PerformanceAnalyticsModule } from './components/modules/PerformanceAnalyticsModule';
import { ProductIntelligenceModule } from './components/modules/ProductIntelligenceModule';
import { ProspectIntelligenceModule } from './components/modules/ProspectIntelligenceModule';
import { SalesSimulationModule } from './components/modules/SalesSimulationModule';
import { SettingsModule } from './components/modules/SettingsModule';
import { SalesOsProvider, useSalesOs } from './context/SalesOsContext';

class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; message: string }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, message: error.message };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-[#070B14] p-6">
          <div className="max-w-lg w-full p-6 rounded-xl border border-red-500/30 bg-white dark:bg-[#0D1322] space-y-3">
            <h2 className="text-base font-semibold text-red-600 dark:text-red-400">
              Application Recovery Required
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-300 font-mono break-all">
              {this.state.message}
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-4 py-2 rounded-lg bg-sky-600 text-white text-xs font-medium cursor-pointer"
            >
              Reload Workspace
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function ActiveModuleRouter() {
  const { activeNav } = useSalesOs();

  switch (activeNav) {
    case 'overview':
      return <OverviewModule />;
    case 'live_assistant':
      return <LiveSalesAssistantModule />;
    case 'objections':
      return <ObjectionIntelligenceModule />;
    case 'closing':
      return <ClosingIntelligenceModule />;
    case 'cold_call':
      return <ColdCallStudioModule />;
    case 'product':
      return <ProductIntelligenceModule />;
    case 'prospects':
      return <ProspectIntelligenceModule />;
    case 'simulation':
      return <SalesSimulationModule />;
    case 'history':
      return <ConversationHistoryModule />;
    case 'knowledge':
      return <KnowledgeBaseModule />;
    case 'learning':
      return <LearningCentreModule />;
    case 'analytics':
      return <PerformanceAnalyticsModule />;
    case 'settings':
      return <SettingsModule />;
    default:
      return <OverviewModule />;
  }
}

function OsShell() {
  const { authLoading, firebaseUser } = useSalesOs();

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-[#070B14]">
        <div className="text-sm text-slate-500 dark:text-slate-400 font-mono">
          Initializing Thaurus Guru Sales Intelligence OS...
        </div>
      </div>
    );
  }

  if (!firebaseUser) {
    return <AuthGate />;
  }

  return (
    <Layout>
      <ActiveModuleRouter />
    </Layout>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <SalesOsProvider>
        <OsShell />
        <OfflineIndicator />
      </SalesOsProvider>
    </ErrorBoundary>
  );
}
