import { BarChart3, Plus } from 'lucide-react';
import React, { useMemo, useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import { recordSalesOutcome } from '../../services/firestoreService';
import type { SalesOutcomeRecord, SimulationCategoryScores } from '../../types';

const SCORE_KEYS: Array<{ key: keyof SimulationCategoryScores; label: string }> = [
  { key: 'opening', label: 'Opening' },
  { key: 'discovery', label: 'Discovery' },
  { key: 'listening', label: 'Listening' },
  { key: 'engagement', label: 'Engagement' },
  { key: 'productKnowledge', label: 'Product Knowledge' },
  { key: 'trustBuilding', label: 'Trust Building' },
  { key: 'objectionHandling', label: 'Objection Handling' },
  { key: 'persuasion', label: 'Persuasion' },
  { key: 'closing', label: 'Closing' },
];

export function PerformanceAnalyticsModule() {
  const { firebaseUser, outcomes, simulations, prospects, notify } = useSalesOs();

  const [showLogForm, setShowLogForm] = useState(false);
  const [outcomeType, setOutcomeType] = useState<SalesOutcomeRecord['outcomeType']>('purchased');
  const [product, setProduct] = useState('');
  const [salesValue, setSalesValue] = useState('0');
  const [strategyUsed, setStrategyUsed] = useState('');
  const [blockingObjection, setBlockingObjection] = useState('');
  const [notes, setNotes] = useState('');

  const analytics = useMemo(() => {
    const counts = {
      replied: outcomes.filter((o) => o.outcomeType === 'replied').length,
      meeting_secured: outcomes.filter((o) => o.outcomeType === 'meeting_secured').length,
      follow_up_scheduled: outcomes.filter((o) => o.outcomeType === 'follow_up_scheduled').length,
      purchased: outcomes.filter((o) => o.outcomeType === 'purchased').length,
      declined: outcomes.filter((o) => o.outcomeType === 'declined').length,
    };

    const revenue = outcomes
      .filter((o) => o.outcomeType === 'purchased')
      .reduce((acc, o) => acc + (o.salesValue || 0), 0);

    const completedSims = simulations.filter((s) => s.status === 'completed');
    const avgSimScore =
      completedSims.length > 0
        ? completedSims.reduce((sum, s) => sum + s.overallScore, 0) / completedSims.length
        : 0;

    const categoryAverages = SCORE_KEYS.map(({ key, label }) => {
      if (completedSims.length === 0) return { label, avg: 0 };
      const sum = completedSims.reduce(
        (acc, sim) => acc + Number(sim.categoryScores?.[key] ?? 0),
        0,
      );
      return { label, avg: sum / completedSims.length };
    });

    const strategySuccess = new Map<string, { wins: number; total: number }>();
    for (const o of outcomes) {
      const strat = o.strategyUsed.trim() || 'Unspecified';
      const curr = strategySuccess.get(strat) ?? { wins: 0, total: 0 };
      curr.total += 1;
      if (o.outcomeType === 'purchased' || o.outcomeType === 'meeting_secured') curr.wins += 1;
      strategySuccess.set(strat, curr);
    }

    return {
      counts,
      revenue,
      completedSims,
      avgSimScore,
      categoryAverages,
      strategies: Array.from(strategySuccess.entries()),
    };
  }, [outcomes, simulations]);

  const handleLogOutcome = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser) return;
    try {
      await recordSalesOutcome({
        userId: firebaseUser.uid,
        outcomeType,
        product: product || 'Thaurus Guru Challenge',
        salesValue: Number(salesValue) || 0,
        currency: 'USD',
        strategyUsed: strategyUsed || 'Consultative Discovery',
        blockingObjection,
        outcomeNotes: notes,
      });
      setShowLogForm(false);
      setProduct('');
      setSalesValue('0');
      setStrategyUsed('');
      setBlockingObjection('');
      setNotes('');
      notify('Sales outcome saved.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save outcome.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
            Performance Analytics
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Real conversion telemetry, strategy outcomes, and 9-dimension simulation progression.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowLogForm((v) => !v)}
          className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Record Sales Outcome</span>
        </button>
      </div>

      {showLogForm && (
        <form
          onSubmit={handleLogOutcome}
          className="p-5 rounded-xl border border-sky-500/40 bg-white dark:bg-[#0D1322] space-y-3 text-xs"
        >
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <select
              value={outcomeType}
              onChange={(e) => setOutcomeType(e.target.value as SalesOutcomeRecord['outcomeType'])}
              className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
            >
              <option value="purchased">Purchased</option>
              <option value="meeting_secured">Meeting Secured</option>
              <option value="replied">Prospect Replied</option>
              <option value="follow_up_scheduled">Follow-Up Scheduled</option>
              <option value="declined">Declined</option>
            </select>
            <input
              type="text"
              value={product}
              onChange={(e) => setProduct(e.target.value)}
              placeholder="Challenge / Product"
              className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
            />
            <input
              type="number"
              min="0"
              value={salesValue}
              onChange={(e) => setSalesValue(e.target.value)}
              placeholder="Value (USD)"
              className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono"
            />
            <input
              type="text"
              value={strategyUsed}
              onChange={(e) => setStrategyUsed(e.target.value)}
              placeholder="Strategy used"
              className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
            />
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              value={blockingObjection}
              onChange={(e) => setBlockingObjection(e.target.value)}
              placeholder="Blocking objection (if declined/stalled)"
              className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
            />
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Notes..."
              className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-emerald-600 text-white font-medium cursor-pointer"
            >
              Save
            </button>
          </div>
        </form>
      )}

      {/* KPI Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500">Total Outcomes Logged</div>
          <div className="text-2xl font-mono font-semibold tabular-nums mt-1">{outcomes.length}</div>
        </div>
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500">Recorded Revenue</div>
          <div className="text-2xl font-mono font-semibold tabular-nums text-emerald-500 mt-1">
            ${analytics.revenue.toLocaleString()}
          </div>
        </div>
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500">Active Prospect Pool</div>
          <div className="text-2xl font-mono font-semibold tabular-nums mt-1">{prospects.length}</div>
        </div>
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
          <div className="text-xs text-slate-500">Avg Simulation Score</div>
          <div className="text-2xl font-mono font-semibold tabular-nums text-sky-500 mt-1">
            {analytics.completedSims.length > 0 ? `${analytics.avgSimScore.toFixed(1)}/10` : '—'}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Simulation Skill Breakdown */}
        <div className="lg:col-span-6 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
              9-Category Simulation Skill Averages
            </h2>
            <span className="text-xs font-mono text-slate-500">
              {analytics.completedSims.length} scored sessions
            </span>
          </div>

          {analytics.completedSims.length === 0 ? (
            <div className="py-10 text-center text-xs text-slate-500">
              Complete a scored roleplay in Sales Simulation to track skill dimensions over time.
            </div>
          ) : (
            <div className="space-y-3">
              {analytics.categoryAverages.map((cat) => (
                <div key={cat.label} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-700 dark:text-slate-300">{cat.label}</span>
                    <span className="font-mono tabular-nums text-slate-900 dark:text-white">
                      {cat.avg.toFixed(1)}/10
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-sky-500 rounded-full"
                      style={{ width: `${Math.min(100, cat.avg * 10)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Outcome Funnel & Strategy Log */}
        <div className="lg:col-span-6 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-4">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-sky-500" />
            <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
              Outcome Breakdown &amp; Strategy Correlation
            </h2>
          </div>

          {outcomes.length === 0 ? (
            <div className="py-10 text-center text-xs text-slate-500">
              No sales outcomes recorded yet. Log real outcomes to uncover winning strategies.
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-xs">
                {[
                  ['Replied', analytics.counts.replied],
                  ['Meetings', analytics.counts.meeting_secured],
                  ['Follow-Up', analytics.counts.follow_up_scheduled],
                  ['Purchased', analytics.counts.purchased],
                  ['Declined', analytics.counts.declined],
                ].map(([lbl, num]) => (
                  <div
                    key={String(lbl)}
                    className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800"
                  >
                    <div className="font-mono font-semibold text-base tabular-nums">{num}</div>
                    <div className="text-slate-500 mt-0.5">{lbl}</div>
                  </div>
                ))}
              </div>

              <div className="divide-y divide-slate-200 dark:divide-slate-800 text-xs">
                {outcomes.slice(0, 8).map((o) => (
                  <div key={o.outcomeId} className="py-2.5 flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="font-medium text-slate-900 dark:text-white truncate">
                        {o.product} · <span className="capitalize">{o.outcomeType.replace('_', ' ')}</span>
                      </div>
                      <div className="text-slate-500 truncate">
                        Strategy: {o.strategyUsed}
                        {o.blockingObjection ? ` · Blocked by: ${o.blockingObjection}` : ''}
                      </div>
                    </div>
                    <div className="font-mono tabular-nums text-slate-800 dark:text-slate-200 shrink-0">
                      ${o.salesValue}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
