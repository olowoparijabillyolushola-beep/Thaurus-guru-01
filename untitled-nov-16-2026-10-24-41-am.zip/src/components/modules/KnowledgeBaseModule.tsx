import { CheckCircle2, FileUp, Globe, Plus, Search, Trash2, WifiOff, XCircle } from 'lucide-react';
import React, { useMemo, useRef, useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import { apiPostJson, apiUploadFile } from '../../services/apiClient';
import {
  deleteKnowledgeSource,
  saveKnowledgeSourceWithChunks,
  updateKnowledgeApproval,
} from '../../services/firestoreService';
import type { KnowledgeSourceRecord } from '../../types';
import { PRODUCT_CATEGORIES } from './ProductIntelligenceModule';

interface ExtractedChunkResponse {
  title: string;
  originalFileName?: string;
  sourceUrl?: string;
  sourceType: KnowledgeSourceRecord['sourceType'];
  contentHash: string;
  chunks: Array<{
    content: string;
    keywords: string[];
    pageNumber: number;
    sectionTitle: string;
  }>;
}

export function KnowledgeBaseModule() {
  const {
    firebaseUser,
    workspaceId,
    isAdmin,
    isOnline,
    offlineLastSyncedAt,
    knowledgeSources,
    knowledgeChunks,
    notify,
  } = useSalesOs();

  const [mode, setMode] = useState<'file' | 'url' | 'manual'>('file');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Challenge types');
  const [docVersion, setDocVersion] = useState('1');
  const [effectiveDate, setEffectiveDate] = useState(new Date().toISOString().slice(0, 10));
  const [urlInput, setUrlInput] = useState('https://thaurusguru.com/');
  const [manualText, setManualText] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [searchTerm, setSearchTerm] = useState('');
  const [previewSourceId, setPreviewSourceId] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const categories = PRODUCT_CATEGORIES.filter((c) => c !== 'All');

  const handleImportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !workspaceId) return;
    setSubmitting(true);
    try {
      let extracted: ExtractedChunkResponse;

      if (mode === 'file') {
        if (!selectedFile) {
          notify('Please choose a PDF, DOCX, TXT, or CSV file.', 'error');
          setSubmitting(false);
          return;
        }
        const fd = new FormData();
        fd.append('file', selectedFile);
        fd.append('title', title.trim() || selectedFile.name);
        extracted = await apiUploadFile<ExtractedChunkResponse>('/api/knowledge/upload', fd);
      } else if (mode === 'url') {
        extracted = await apiPostJson<ExtractedChunkResponse>('/api/knowledge/import-url', {
          url: urlInput.trim(),
          title: title.trim(),
        });
      } else {
        if (!manualText.trim()) {
          notify('Please enter verified policy text.', 'error');
          setSubmitting(false);
          return;
        }
        const raw = manualText.trim();
        const words = raw.toLowerCase().split(/\s+/).filter((w) => w.length >= 4);
        const hashBytes = new TextEncoder().encode(raw);
        const digest = await crypto.subtle.digest('SHA-256', hashBytes);
        const contentHash = Array.from(new Uint8Array(digest))
          .map((b) => b.toString(16).padStart(2, '0'))
          .join('')
          .slice(0, 32);

        extracted = {
          title: title.trim() || `${category} Policy`,
          sourceType: 'manual',
          contentHash,
          chunks: [
            {
              content: raw.slice(0, 5800),
              keywords: Array.from(new Set(words)).slice(0, 16),
              pageNumber: 1,
              sectionTitle: category,
            },
          ],
        };
      }

      await saveKnowledgeSourceWithChunks({
        workspaceId,
        uploadedBy: firebaseUser.uid,
        isAdmin,
        title: title.trim() || extracted.title,
        sourceType: extracted.sourceType,
        originalFileName: extracted.originalFileName,
        sourceUrl: extracted.sourceUrl,
        category,
        documentVersion: Math.max(1, Number(docVersion) || 1),
        effectiveDate,
        contentHash: extracted.contentHash,
        chunks: extracted.chunks,
      });

      setTitle('');
      setManualText('');
      setSelectedFile(null);
      if (fileRef.current) fileRef.current.value = '';
      notify(
        isAdmin
          ? `Imported & approved ${extracted.chunks.length} searchable chunks.`
          : `Uploaded ${extracted.chunks.length} chunks for administrator review.`,
        'success',
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Knowledge import failed.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleApproval = async (
    sourceId: string,
    status: KnowledgeSourceRecord['approvalStatus'],
  ) => {
    if (!firebaseUser) return;
    try {
      await updateKnowledgeApproval({
        sourceId,
        chunks: knowledgeChunks,
        status,
        adminUid: firebaseUser.uid,
      });
      notify(`Source marked as ${status}.`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Approval update failed.', 'error');
    }
  };

  const filteredSources = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return knowledgeSources;
    return knowledgeSources.filter((src) => {
      if (
        src.title.toLowerCase().includes(q) ||
        src.category.toLowerCase().includes(q) ||
        src.sourceType.toLowerCase().includes(q)
      ) {
        return true;
      }
      return knowledgeChunks.some(
        (ch) =>
          ch.sourceId === src.sourceId &&
          (ch.content.toLowerCase().includes(q) || ch.sectionTitle.toLowerCase().includes(q)),
      );
    });
  }, [knowledgeSources, knowledgeChunks, searchTerm]);

  const previewChunks = useMemo(() => {
    const base = knowledgeChunks.filter((c) => c.sourceId === previewSourceId);
    const q = searchTerm.trim().toLowerCase();
    if (!q) return base;
    const matches = base.filter(
      (c) => c.content.toLowerCase().includes(q) || c.sectionTitle.toLowerCase().includes(q),
    );
    return matches.length > 0 ? matches : base;
  }, [knowledgeChunks, previewSourceId, searchTerm]);

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
          Knowledge Base &amp; RAG Ingestion
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          Explicitly upload company files (PDF, DOCX, TXT, CSV) or import verified web pages such
          as <span className="font-mono">https://thaurusguru.com/</span> with version governance.
        </p>
      </div>

      {!isOnline && (
        <div className="p-3 rounded-xl border border-amber-500/35 bg-amber-500/10 text-xs text-amber-800 dark:text-amber-200 flex items-center gap-2">
          <WifiOff className="w-4 h-4 text-amber-500 shrink-0" />
          <span>
            Offline Field Mode active — {knowledgeSources.length} Knowledge Sources and{' '}
            {knowledgeChunks.length} policy chunks remain searchable locally
            {offlineLastSyncedAt
              ? ` (synced ${new Date(offlineLastSyncedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})`
              : ''}
            . New uploads/URL imports require connectivity.
          </span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Ingestion Form */}
        <form
          onSubmit={handleImportSubmit}
          className="lg:col-span-5 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-4 h-fit"
        >
          <div className="grid grid-cols-3 gap-1 p-1 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setMode('file')}
              className={`py-1.5 rounded text-xs font-medium cursor-pointer ${
                mode === 'file' ? 'bg-sky-600 text-white' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Upload File
            </button>
            <button
              type="button"
              onClick={() => setMode('url')}
              className={`py-1.5 rounded text-xs font-medium cursor-pointer ${
                mode === 'url' ? 'bg-sky-600 text-white' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Import URL
            </button>
            <button
              type="button"
              onClick={() => setMode('manual')}
              className={`py-1.5 rounded text-xs font-medium cursor-pointer ${
                mode === 'manual' ? 'bg-sky-600 text-white' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Manual Policy
            </button>
          </div>

          <div>
            <label className="block text-xs text-slate-500 mb-1">Source Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Thaurus Guru Challenge Specifications"
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
            />
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-2">
              <label className="block text-xs text-slate-500 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
              >
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">Version</label>
              <input
                type="number"
                min="1"
                value={docVersion}
                onChange={(e) => setDocVersion(e.target.value)}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-500 mb-1">Effective Date</label>
            <input
              type="date"
              value={effectiveDate}
              onChange={(e) => setEffectiveDate(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
            />
          </div>

          {mode === 'file' && (
            <div>
              <input
                ref={fileRef}
                type="file"
                accept=".pdf,.docx,.txt,.csv,.md"
                onChange={(e) => setSelectedFile(e.target.files?.[0] ?? null)}
                className="block w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-medium file:bg-sky-600/15 file:text-sky-600 dark:file:text-sky-400 cursor-pointer"
              />
            </div>
          )}

          {mode === 'url' && (
            <div>
              <label className="block text-xs text-slate-500 mb-1">Official Page URL</label>
              <div className="relative">
                <Globe className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="url"
                  required
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Explicitly fetches and extracts text from the single specified URL only.
              </p>
            </div>
          )}

          {mode === 'manual' && (
            <div>
              <label className="block text-xs text-slate-500 mb-1">Verified Policy Text</label>
              <textarea
                rows={5}
                value={manualText}
                onChange={(e) => setManualText(e.target.value)}
                placeholder="Paste verified pricing, drawdown rules, payout schedule, or FAQ..."
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 px-4 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-medium inline-flex items-center justify-center gap-1.5 cursor-pointer"
          >
            {mode === 'file' ? (
              <FileUp className="w-3.5 h-3.5" />
            ) : mode === 'url' ? (
              <Globe className="w-3.5 h-3.5" />
            ) : (
              <Plus className="w-3.5 h-3.5" />
            )}
            <span>{submitting ? 'Extracting & Chunking...' : 'Ingest Knowledge Source'}</span>
          </button>
        </form>

        {/* Source Inventory & Chunk Preview */}
        <div className="lg:col-span-7 space-y-4">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-3">
                <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
                  Knowledge Sources ({filteredSources.length})
                </h2>
                <span className="text-xs font-mono text-slate-500">
                  {knowledgeChunks.length} chunks
                </span>
              </div>
              <div className="relative w-full sm:w-56">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search rules, payouts, titles..."
                  className="w-full pl-8 pr-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
                />
              </div>
            </div>

            {filteredSources.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                {knowledgeSources.length === 0
                  ? 'No knowledge sources ingested yet. Upload a document or import a URL to ground product answers.'
                  : 'No cached knowledge sources matched your search.'}
              </div>
            ) : (
              <div className="divide-y divide-slate-200 dark:divide-slate-800">
                {filteredSources.map((src) => {
                  const chunkCount = knowledgeChunks.filter((c) => c.sourceId === src.sourceId).length;
                  return (
                    <div key={src.sourceId} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="min-w-0">
                        <button
                          type="button"
                          onClick={() =>
                            setPreviewSourceId(previewSourceId === src.sourceId ? null : src.sourceId)
                          }
                          className="text-sm font-medium text-slate-900 dark:text-white hover:text-sky-500 text-left truncate block cursor-pointer"
                        >
                          {src.title}
                        </button>
                        <div className="text-xs text-slate-500 mt-1 flex flex-wrap items-center gap-1.5">
                          <span className="uppercase font-mono">{src.sourceType}</span>
                          <span>·</span>
                          <span>{src.category}</span>
                          <span>·</span>
                          <span className="font-mono">v{src.documentVersion}</span>
                          <span>·</span>
                          <span className="font-mono">{chunkCount} chunks</span>
                          <span>·</span>
                          <span
                            className={
                              src.approvalStatus === 'approved'
                                ? 'text-emerald-600 dark:text-emerald-400 font-medium'
                                : src.approvalStatus === 'pending'
                                  ? 'text-amber-600 dark:text-amber-400 font-medium'
                                  : 'text-red-500'
                            }
                          >
                            {src.approvalStatus}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {isAdmin && src.approvalStatus !== 'approved' && (
                          <button
                            type="button"
                            onClick={() => void handleApproval(src.sourceId, 'approved')}
                            className="px-2.5 py-1 rounded bg-emerald-600 text-white text-xs inline-flex items-center gap-1 cursor-pointer"
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Approve</span>
                          </button>
                        )}
                        {isAdmin && src.approvalStatus === 'approved' && (
                          <button
                            type="button"
                            onClick={() => void handleApproval(src.sourceId, 'superseded')}
                            className="px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 inline-flex items-center gap-1 cursor-pointer"
                          >
                            <XCircle className="w-3 h-3" />
                            <span>Supersede</span>
                          </button>
                        )}
                        {(isAdmin || src.approvalStatus === 'pending') && (
                          <button
                            type="button"
                            onClick={() => void deleteKnowledgeSource(src.sourceId, knowledgeChunks)}
                            className="p-1.5 text-slate-500 hover:text-red-500 cursor-pointer"
                            title="Delete source"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {previewSourceId && (
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold text-slate-900 dark:text-white">
                  Extracted Chunks Preview ({previewChunks.length})
                </h3>
                <button
                  type="button"
                  onClick={() => setPreviewSourceId(null)}
                  className="text-xs text-slate-500"
                >
                  Close
                </button>
              </div>
              <div className="space-y-2 max-h-72 overflow-y-auto">
                {previewChunks.map((ch) => (
                  <div
                    key={ch.chunkId}
                    className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-xs"
                  >
                    <div className="font-medium text-sky-600 dark:text-sky-400 mb-1">
                      {ch.sectionTitle} · Page {ch.pageNumber}
                    </div>
                    <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                      {ch.content}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
