import { ArrowUpRight, History, Search, Trash2, Users } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import {
  deleteConversation,
  subscribeConversationMessages,
  updateConversationStatus,
} from '../../services/firestoreService';
import type { ConversationMessage, ConversationRecord } from '../../types';

export function ConversationHistoryModule() {
  const {
    firebaseUser,
    conversations,
    setActiveConversationId,
    setActiveNav,
    setDraftAnalysisText,
    notify,
  } = useSalesOs();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ConversationMessage[]>([]);

  useEffect(() => {
    if (!selectedId || !firebaseUser) {
      setMessages([]);
      return;
    }
    const unsub = subscribeConversationMessages(selectedId, firebaseUser.uid, setMessages);
    return () => unsub();
  }, [selectedId, firebaseUser]);

  const filtered = conversations.filter((c) => {
    const matchesSearch =
      !search ||
      c.title.toLowerCase().includes(search.toLowerCase()) ||
      c.channel.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const selectedConv = conversations.find((c) => c.conversationId === selectedId) ?? null;

  const handleResume = (convId: string) => {
    setActiveConversationId(convId);
    setActiveNav('live_assistant');
  };

  const handleSendToProspectAnalysis = () => {
    if (messages.length === 0) return;
    const text = messages
      .map((m) => `${m.role === 'user' ? 'Executive' : 'AI/Prospect'}: ${m.content}`)
      .join('\n\n');
    setDraftAnalysisText(text);
    if (selectedConv) {
      void updateConversationStatus(selectedConv.conversationId, { analysed: true });
    }
    setActiveNav('prospects');
  };

  const handleStatusChange = async (
    conv: ConversationRecord,
    status: ConversationRecord['status'],
  ) => {
    try {
      await updateConversationStatus(conv.conversationId, { status });
      notify('Conversation status updated.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Update failed.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
          Conversation History
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          Inspect saved executive sales threads, update deal statuses, or push transcripts into
          Prospect Intelligence.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-5 space-y-3">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search threads..."
                className="w-full pl-8 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0D1322] text-xs"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0D1322] text-xs"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active</option>
              <option value="follow_up">Follow-Up</option>
              <option value="converted">Converted</option>
              <option value="closed_lost">Closed Lost</option>
            </select>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] divide-y divide-slate-200 dark:divide-slate-800 max-h-[560px] overflow-y-auto">
            {filtered.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                No conversations found.
              </div>
            ) : (
              filtered.map((c) => (
                <button
                  key={c.conversationId}
                  type="button"
                  onClick={() => setSelectedId(c.conversationId)}
                  className={`w-full text-left p-3.5 transition-colors cursor-pointer ${
                    selectedId === c.conversationId
                      ? 'bg-sky-600/10'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <div className="text-sm font-medium text-slate-900 dark:text-white truncate">
                    {c.title}
                  </div>
                  <div className="text-xs text-slate-500 mt-1 flex items-center gap-2">
                    <span>{c.channel}</span>
                    <span>·</span>
                    <span className="capitalize">{c.status.replace('_', ' ')}</span>
                    {c.analysed && (
                      <>
                        <span>·</span>
                        <span className="text-emerald-600 dark:text-emerald-400">Analysed</span>
                      </>
                    )}
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        <div className="lg:col-span-7">
          {!selectedConv ? (
            <div className="p-10 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] text-center">
              <History className="w-8 h-8 text-sky-500 mx-auto mb-3" />
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Select a conversation on the left to inspect its full transcript.
              </p>
            </div>
          ) : (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] flex flex-col h-[600px]">
              <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                <div className="min-w-0">
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                    {selectedConv.title}
                  </h3>
                  <div className="text-xs text-slate-500">
                    {selectedConv.channel} · {selectedConv.mode} mode
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <select
                    value={selectedConv.status}
                    onChange={(e) =>
                      void handleStatusChange(
                        selectedConv,
                        e.target.value as ConversationRecord['status'],
                      )
                    }
                    className="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
                  >
                    <option value="active">Active</option>
                    <option value="follow_up">Follow-Up</option>
                    <option value="converted">Converted</option>
                    <option value="closed_lost">Closed Lost</option>
                  </select>
                  <button
                    type="button"
                    onClick={handleSendToProspectAnalysis}
                    className="px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 text-xs inline-flex items-center gap-1 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    <Users className="w-3 h-3" />
                    <span>Analyse</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleResume(selectedConv.conversationId)}
                    className="px-2.5 py-1 rounded bg-sky-600 text-white text-xs inline-flex items-center gap-1 cursor-pointer"
                  >
                    <span>Resume</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      void deleteConversation(selectedConv.conversationId);
                      setSelectedId(null);
                    }}
                    className="p-1.5 text-slate-500 hover:text-red-500 cursor-pointer"
                    title="Delete thread"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {messages.length === 0 ? (
                  <p className="text-xs text-slate-500">No messages recorded in this thread.</p>
                ) : (
                  messages.map((m) => (
                    <div
                      key={m.messageId}
                      className={`p-3 rounded-lg text-xs leading-relaxed whitespace-pre-wrap ${
                        m.role === 'user'
                          ? 'bg-sky-600/10 border border-sky-500/20 text-slate-900 dark:text-slate-100'
                          : 'bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200'
                      }`}
                    >
                      <div className="font-semibold mb-1 text-[11px] text-slate-500">
                        {m.role === 'user' ? 'Sales Executive' : 'Thaurus Guru Intelligence'}
                      </div>
                      {m.content}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
