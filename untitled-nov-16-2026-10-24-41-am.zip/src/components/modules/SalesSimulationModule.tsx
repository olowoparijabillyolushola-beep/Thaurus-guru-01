import { Award, Brain, Play, Send, Square, Volume2, VolumeX } from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import { apiPostJson } from '../../services/apiClient';
import {
  appendSimulationTranscript,
  createSimulation,
  finalizeSimulationScore,
} from '../../services/firestoreService';
import type {
  SimulationRecord,
  SimulationScoreResult,
  SimulationTranscriptTurn,
} from '../../types';
import { VoiceRecorderButton } from '../VoiceRecorderButton';

const PROSPECT_CATEGORIES = [
  'Beginner trader',
  'Experienced trader',
  'Sceptical trader',
  'Price-sensitive trader',
  'Disappointed prop firm customer',
  'Existing funded trader',
  'Busy prospect',
  'Aggressive prospect',
  'Highly informed prospect',
  'Interested but indecisive prospect',
];

const DIFFICULTIES: SimulationRecord['difficulty'][] = [
  'Beginner',
  'Intermediate',
  'Advanced',
  'Expert',
];

const RUBRIC_LABELS: Array<{ key: keyof SimulationScoreResult['categoryScores']; label: string }> = [
  { key: 'opening', label: 'Opening' },
  { key: 'discovery', label: 'Discovery' },
  { key: 'listening', label: 'Listening' },
  { key: 'engagement', label: 'Engagement' },
  { key: 'productKnowledge', label: 'Product Knowledge' },
  { key: 'trustBuilding', label: 'Trust Building' },
  { key: 'objectionHandling', label: 'Objection Handling' },
  { key: 'persuasion', label: 'Persuasion' },
  { key: 'closing', label: 'Closing' },
];

export function SalesSimulationModule() {
  const {
    firebaseUser,
    isOnline,
    simulations,
    draftSimScenario,
    setDraftSimScenario,
    buildAiContext,
    notify,
  } = useSalesOs();

  const [prospectType, setProspectType] = useState(PROSPECT_CATEGORIES[2]);
  const [difficulty, setDifficulty] = useState<SimulationRecord['difficulty']>('Intermediate');
  const [scenarioNotes, setScenarioNotes] = useState('');

  const [activeSimId, setActiveSimId] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<SimulationTranscriptTurn[]>([]);
  const [executiveReply, setExecutiveReply] = useState('');
  const [busy, setBusy] = useState(false);
  const [scoring, setScoring] = useState(false);
  const [scoreView, setScoreView] = useState<SimulationRecord | null>(null);

  // Hands-free call practice state
  const [handsFreeVoice, setHandsFreeVoice] = useState(true);
  const [speakProspectReplies, setSpeakProspectReplies] = useState(false);

  const speakText = (text: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.02;
    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  useEffect(() => {
    if (draftSimScenario) {
      setProspectType(draftSimScenario.prospectType);
      setScenarioNotes(draftSimScenario.notes);
      setDraftSimScenario(null);
    }
  }, [draftSimScenario, setDraftSimScenario]);

  const handleStartSimulation = async () => {
    if (!firebaseUser) return;
    setBusy(true);
    setScoreView(null);
    try {
      const ctx = buildAiContext(`${prospectType} ${scenarioNotes}`);
      const res = await apiPostJson<{ reply: string }>('/api/ai/simulation/turn', {
        prospectType,
        difficulty,
        scenarioNotes,
        transcript: [],
        context: ctx,
      });
      const initialTurn: SimulationTranscriptTurn[] = [
        { speaker: 'prospect', text: res.reply, timestampIso: new Date().toISOString() },
      ];
      const simId = await createSimulation({
        userId: firebaseUser.uid,
        prospectType,
        difficulty,
        initialTranscript: initialTurn,
      });
      setActiveSimId(simId);
      setTranscript(initialTurn);
      if (speakProspectReplies) {
        speakText(res.reply);
      }
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Unable to start simulation.', 'error');
    } finally {
      setBusy(false);
    }
  };

  const submitExecutiveTurn = async (textToSubmit: string) => {
    if (!activeSimId || !textToSubmit.trim()) return;

    const updated: SimulationTranscriptTurn[] = [
      ...transcript,
      {
        speaker: 'executive',
        text: textToSubmit.trim(),
        timestampIso: new Date().toISOString(),
      },
    ];
    setTranscript(updated);
    setExecutiveReply('');
    setBusy(true);

    try {
      const ctx = buildAiContext(updated[updated.length - 1].text);
      const res = await apiPostJson<{ reply: string }>('/api/ai/simulation/turn', {
        prospectType,
        difficulty,
        scenarioNotes,
        transcript: updated.map((t) => ({ speaker: t.speaker, text: t.text })),
        context: ctx,
      });
      const withReply: SimulationTranscriptTurn[] = [
        ...updated,
        { speaker: 'prospect', text: res.reply, timestampIso: new Date().toISOString() },
      ];
      setTranscript(withReply);
      await appendSimulationTranscript(activeSimId, withReply);
      if (speakProspectReplies) {
        speakText(res.reply);
      }
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Simulation turn failed.', 'error');
    } finally {
      setBusy(false);
    }
  };

  const handleSendTurn = async (e: React.FormEvent) => {
    e.preventDefault();
    await submitExecutiveTurn(executiveReply);
  };

  const handleScoreSimulation = async () => {
    if (!activeSimId || transcript.length < 2) {
      notify('Complete at least one executive response before scoring.', 'error');
      return;
    }
    setScoring(true);
    try {
      const ctx = buildAiContext(`${prospectType} ${difficulty}`);
      const res = await apiPostJson<{ data: SimulationScoreResult }>('/api/ai/simulation/score', {
        prospectType,
        difficulty,
        transcript: transcript.map((t) => ({ speaker: t.speaker, text: t.text })),
        context: ctx,
      });

      const d = res.data;
      const compiledFeedback = `${d.detailedFeedback}\n\nStrongest Area: ${d.strongestArea}\nBiggest Missed Opportunity: ${d.biggestMissedOpportunity}\nBetter Alternative Response: ${d.betterAlternativeResponse}`;

      await finalizeSimulationScore({
        simulationId: activeSimId,
        transcript,
        categoryScores: d.categoryScores,
        overallScore: d.overallScore,
        feedback: compiledFeedback,
        improvementTarget: d.measurableImprovementTarget,
      });

      const completedSim: SimulationRecord = {
        simulationId: activeSimId,
        userId: firebaseUser?.uid || '',
        prospectType,
        difficulty,
        transcript,
        categoryScores: d.categoryScores,
        overallScore: d.overallScore,
        feedback: compiledFeedback,
        improvementTarget: d.measurableImprovementTarget,
        status: 'completed',
      };
      setScoreView(completedSim);
      setActiveSimId(null);
      notify(`Simulation scored: ${d.overallScore}/10`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Scoring failed.', 'error');
    } finally {
      setScoring(false);
    }
  };

  const completedHistory = simulations.filter((s) => s.status === 'completed');

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
          Sales Simulation &amp; Hands-Free Call Practice
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          Roleplay realistic, challenging prop-trading prospects by text or voice with strict
          9-category scoring.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Scenario Builder & Past Scores */}
        <div className="lg:col-span-4 space-y-4">
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-3">
            <h2 className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Scenario Configuration
            </h2>
            <div>
              <label className="block text-xs text-slate-500 mb-1">Prospect Archetype</label>
              <select
                value={prospectType}
                onChange={(e) => setProspectType(e.target.value)}
                disabled={Boolean(activeSimId)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
              >
                {PROSPECT_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">Difficulty Level</label>
              <div className="grid grid-cols-2 gap-1.5">
                {DIFFICULTIES.map((diff) => (
                  <button
                    key={diff}
                    type="button"
                    disabled={Boolean(activeSimId)}
                    onClick={() => setDifficulty(diff)}
                    className={`py-1.5 px-2 rounded text-xs font-medium cursor-pointer ${
                      difficulty === diff
                        ? 'bg-sky-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">Optional Scenario Focus</label>
              <input
                type="text"
                value={scenarioNotes}
                onChange={(e) => setScenarioNotes(e.target.value)}
                disabled={Boolean(activeSimId)}
                placeholder="e.g. Prospect doubts payout reliability"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
              />
            </div>

            <div className="pt-1 space-y-2 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={handsFreeVoice}
                  onChange={(e) => setHandsFreeVoice(e.target.checked)}
                  className="accent-sky-600"
                />
                <span>Hands-free voice auto-send on stop</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={speakProspectReplies}
                  onChange={(e) => setSpeakProspectReplies(e.target.checked)}
                  className="accent-sky-600"
                />
                <span>Read prospect responses aloud</span>
              </label>
            </div>

            {!activeSimId ? (
              <button
                type="button"
                disabled={busy || !isOnline}
                onClick={() => void handleStartSimulation()}
                className="w-full py-2.5 px-4 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-medium inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5" />
                <span>{busy ? 'Initializing Prospect...' : 'Start Roleplay Simulation'}</span>
              </button>
            ) : (
              <button
                type="button"
                disabled={scoring || transcript.length < 2}
                onClick={() => void handleScoreSimulation()}
                className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-medium inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Square className="w-3.5 h-3.5" />
                <span>{scoring ? 'Scoring Performance...' : 'End & Score Simulation'}</span>
              </button>
            )}
          </div>

          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-2">
            <h3 className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Completed Simulations ({completedHistory.length})
            </h3>
            {completedHistory.length === 0 ? (
              <p className="text-xs text-slate-500">No scored simulations recorded yet.</p>
            ) : (
              <div className="space-y-1.5 max-h-72 overflow-y-auto">
                {completedHistory.map((sim) => (
                  <button
                    key={sim.simulationId}
                    type="button"
                    onClick={() => setScoreView(sim)}
                    className="w-full text-left p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:border-sky-500/40 text-xs flex items-center justify-between gap-2 cursor-pointer"
                  >
                    <div className="min-w-0">
                      <div className="font-medium text-slate-900 dark:text-white truncate">
                        {sim.prospectType}
                      </div>
                      <div className="text-slate-500">{sim.difficulty}</div>
                    </div>
                    <div className="font-mono font-semibold tabular-nums text-sky-600 dark:text-sky-400 shrink-0">
                      {sim.overallScore.toFixed(1)}/10
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right: Active Roleplay or Score Evaluation */}
        <div className="lg:col-span-8">
          {scoreView ? (
            <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-5">
              <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
                <div>
                  <div className="text-xs text-slate-500">
                    {scoreView.prospectType} · {scoreView.difficulty}
                  </div>
                  <h3 className="text-lg font-semibold text-slate-900 dark:text-white mt-0.5">
                    Simulation Performance Scorecard
                  </h3>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-sky-500" />
                  <span className="text-2xl font-mono font-semibold tabular-nums text-slate-900 dark:text-white">
                    {scoreView.overallScore.toFixed(1)}/10
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {RUBRIC_LABELS.map(({ key, label }) => {
                  const val = Number(scoreView.categoryScores?.[key] ?? 0);
                  return (
                    <div
                      key={key}
                      className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50"
                    >
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="text-slate-600 dark:text-slate-300">{label}</span>
                        <span className="font-mono font-semibold tabular-nums text-slate-900 dark:text-white">
                          {val.toFixed(1)}
                        </span>
                      </div>
                      <div className="w-full h-1.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-sky-500 rounded-full"
                          style={{ width: `${Math.min(100, val * 10)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="p-4 rounded-lg bg-sky-500/8 border border-sky-500/25 text-xs">
                <div className="font-semibold text-sky-600 dark:text-sky-400 mb-1">
                  Measurable Improvement Target
                </div>
                <div className="text-slate-800 dark:text-slate-200">
                  {scoreView.improvementTarget}
                </div>
              </div>

              <div className="text-xs text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">
                {scoreView.feedback}
              </div>
            </div>
          ) : !activeSimId ? (
            <div className="p-10 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] text-center">
              <Brain className="w-8 h-8 text-sky-500 mx-auto mb-3" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Configure a prospect profile to begin roleplay
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
                Practise live cold calls hands-free using Gemini voice transcription, or type turns
                one step at a time.
              </p>
            </div>
          ) : (
            <div className="flex flex-col h-[540px] rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 text-xs">
                <span className="font-medium text-slate-900 dark:text-white truncate">
                  Live Roleplay: {prospectType} ({difficulty})
                </span>
                <div className="flex items-center gap-3 shrink-0">
                  <button
                    type="button"
                    onClick={() => setSpeakProspectReplies((v) => !v)}
                    className="inline-flex items-center gap-1 text-slate-500 hover:text-sky-500 cursor-pointer"
                    title="Toggle spoken prospect replies"
                  >
                    {speakProspectReplies ? (
                      <Volume2 className="w-3.5 h-3.5 text-sky-500" />
                    ) : (
                      <VolumeX className="w-3.5 h-3.5" />
                    )}
                    <span className="hidden sm:inline">Voice Audio</span>
                  </button>
                  <span className="font-mono text-slate-500">{transcript.length} turns</span>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {transcript.map((turn, idx) => (
                  <div
                    key={idx}
                    className={`flex flex-col ${
                      turn.speaker === 'executive' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 mb-1">
                      <span>
                        {turn.speaker === 'executive' ? 'You (Sales Executive)' : prospectType}
                      </span>
                      {turn.speaker === 'prospect' && (
                        <button
                          type="button"
                          onClick={() => speakText(turn.text)}
                          className="text-slate-400 hover:text-sky-500 cursor-pointer"
                          title="Play prospect turn aloud"
                        >
                          <Volume2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                    <div
                      className={`max-w-xl px-3.5 py-2.5 rounded-xl text-sm leading-relaxed ${
                        turn.speaker === 'executive'
                          ? 'bg-sky-600 text-white'
                          : 'border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100'
                      }`}
                    >
                      {turn.text}
                    </div>
                  </div>
                ))}
              </div>

              <form
                onSubmit={handleSendTurn}
                className="p-3 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2 bg-slate-50/70 dark:bg-[#0A0F1C]"
              >
                <VoiceRecorderButton
                  disabled={busy || !isOnline}
                  label={handsFreeVoice ? 'Speak' : undefined}
                  contextHint={`Sales simulation roleplay against ${prospectType} (${difficulty})`}
                  onTranscript={(text) => {
                    if (handsFreeVoice) {
                      void submitExecutiveTurn(text);
                    } else {
                      setExecutiveReply((prev) => (prev.trim() ? `${prev.trim()} ${text}` : text));
                    }
                  }}
                  onError={(msg) => notify(msg, 'error')}
                />
                <input
                  type="text"
                  value={executiveReply}
                  onChange={(e) => setExecutiveReply(e.target.value)}
                  placeholder={
                    handsFreeVoice
                      ? 'Tap Speak to talk hands-free, or type a reply...'
                      : 'Type your response as the Sales Executive...'
                  }
                  className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                />
                <button
                  type="submit"
                  disabled={busy || !isOnline || !executiveReply.trim()}
                  className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer shrink-0 whitespace-nowrap"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{busy ? 'Replying...' : 'Send'}</span>
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
