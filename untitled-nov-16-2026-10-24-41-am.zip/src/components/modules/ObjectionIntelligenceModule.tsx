import { AlertTriangle, Check, Copy, MessageCircle, ShieldAlert } from 'lucide-react';
import React, { useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import { apiPostJson } from '../../services/apiClient';
import { createLearningRecord } from '../../services/firestoreService';
import type { CommunicationChannel, CommunicationStyle, ObjectionAnalysisResult } from '../../types';
import { buildWhatsAppUrl } from '../../utils/whatsapp';

const COMMON_OBJECTIONS = [
  'Your challenge is expensive.',
  'Why should I trust Thaurus Guru?',
  "I've been disappointed by other prop firms.",
  'What makes you different?',
  'Is this legitimate?',
  'What happens if I fail?',
  'How do payouts work?',
  'I need to think about it.',
  "I don't have the money now.",
  "I don't trust the trading rules.",
];

export function ObjectionIntelligenceModule() {
  const {
    firebaseUser,
    workspaceId,
    isAdmin,
    currentInstructionVersion,
    prospects,
    buildAiContext,
    notify,
  } = useSalesOs();

  const [objection, setObjection] = useState(COMMON_OBJECTIONS[0]);
  const [channel, setChannel] = useState<CommunicationChannel>('WhatsApp');
  const [style, setStyle] = useState<CommunicationStyle>('Confident');
  const [prospectId, setProspectId] = useState('');
  const [extraContext, setExtraContext] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ObjectionAnalysisResult | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const selectedProspect = prospects.find((p) => p.prospectId === prospectId) ?? null;

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!objection.trim()) return;
    setLoading(true);
    try {
      const ctx = buildAiContext(objection, selectedProspect);
      const res = await apiPostJson<{ data: ObjectionAnalysisResult }>('/api/ai/objection', {
        objection,
        channel,
        style,
        extraContext,
        context: ctx,
      });
      setResult(res.data);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Objection analysis failed.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleLogGap = async () => {
    if (!firebaseUser || !workspaceId || !result?.missingKnowledgeGap) return;
    try {
      await createLearningRecord({
        workspaceId,
        recordType: 'knowledge_gap',
        title: `Missing evidence for objection: ${result.surfaceObjection.slice(0, 80)}`,
        description: result.missingKnowledgeGap,
        evidenceSummary: `Triggered in Objection Intelligence for "${objection}"`,
        instructionVersion: currentInstructionVersion,
        createdBy: firebaseUser.uid,
        isAdmin,
      });
      notify('Knowledge gap logged to Learning Centre (Layer 4).', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to log knowledge gap.', 'error');
    }
  };

  const copyText = async (key: string, text: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1600);
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
          Objection Intelligence Engine
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          Deconstruct surface pushback into underlying prospect concerns using verified Thaurus
          Guru evidence.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Presets + Form */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322]">
            <h2 className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2.5">
              Common Prop-Trading Objections
            </h2>
            <div className="space-y-1">
              {COMMON_OBJECTIONS.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setObjection(item)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-colors cursor-pointer ${
                    objection === item
                      ? 'bg-sky-600/12 text-sky-600 dark:text-sky-400 font-medium'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <form
            onSubmit={handleAnalyze}
            className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-3"
          >
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Objection Statement
              </label>
              <textarea
                rows={3}
                value={objection}
                onChange={(e) => setObjection(e.target.value)}
                className="w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3 py-2 text-sm text-slate-900 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs text-slate-500 mb-1">Channel</label>
                <select
                  value={channel}
                  onChange={(e) => setChannel(e.target.value as CommunicationChannel)}
                  className="w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
                >
                  <option value="WhatsApp">WhatsApp</option>
                  <option value="Telephone call">Telephone call</option>
                  <option value="Email">Email</option>
                  <option value="Face-to-face">Face-to-face</option>
                  <option value="Social media">Social media</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Tone</label>
                <select
                  value={style}
                  onChange={(e) => setStyle(e.target.value as CommunicationStyle)}
                  className="w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
                >
                  <option value="Confident">Confident</option>
                  <option value="Natural">Natural</option>
                  <option value="Persuasive">Persuasive</option>
                  <option value="Professional">Professional</option>
                  <option value="Direct">Direct</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">Prospect Context (Optional)</label>
              <select
                value={prospectId}
                onChange={(e) => setProspectId(e.target.value)}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
              >
                <option value="">No specific prospect</option>
                {prospects.map((p) => (
                  <option key={p.prospectId} value={p.prospectId}>
                    {p.displayName}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">Situation Notes</label>
              <input
                type="text"
                value={extraContext}
                onChange={(e) => setExtraContext(e.target.value)}
                placeholder="e.g. Prospect previously failed a 2-step at another firm"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
              />
            </div>

            <button
              type="submit"
              disabled={loading || !objection.trim()}
              className="w-full py-2.5 px-4 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-sm font-medium transition-colors cursor-pointer"
            >
              {loading ? 'Analysing Objection...' : 'Analyse Objection'}
            </button>
          </form>
        </div>

        {/* Right: Structured 7-Part Breakdown */}
        <div className="lg:col-span-7">
          {!result ? (
            <div className="p-10 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] text-center">
              <ShieldAlert className="w-8 h-8 text-sky-500 mx-auto mb-3" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Select or enter an objection to inspect
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
                The engine separates the surface claim from the prospect&apos;s underlying fear,
                pulls verified Knowledge Base proof, and prepares primary + alternative replies.
              </p>
            </div>
          ) : (
            <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <div className="text-xs text-slate-500">1. Surface Objection</div>
                  <div className="text-sm font-medium text-slate-900 dark:text-white mt-1">
                    {result.surfaceObjection}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">2. Underlying Concern</div>
                  <div className="text-sm text-slate-800 dark:text-slate-200 mt-1">
                    {result.underlyingConcern}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">3. Likely Motivation</div>
                  <div className="text-sm text-slate-800 dark:text-slate-200 mt-1">
                    {result.prospectMotivation}
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="text-xs font-semibold text-sky-600 dark:text-sky-400">
                    4. Recommended Response
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <a
                      href={buildWhatsAppUrl(
                        result.recommendedResponse,
                        selectedProspect?.contactDetails,
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 hover:underline whitespace-nowrap"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => void copyText('primary', result.recommendedResponse)}
                      className="inline-flex items-center gap-1 text-xs text-slate-600 dark:text-slate-300 hover:text-sky-500 cursor-pointer whitespace-nowrap"
                    >
                      {copiedKey === 'primary' ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-500" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
                <p className="text-sm text-slate-900 dark:text-slate-100 leading-relaxed whitespace-pre-wrap">
                  {result.recommendedResponse}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-200 dark:border-slate-800">
                <div>
                  <div className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    5. Supporting Verified Evidence
                  </div>
                  {result.supportingEvidence.length === 0 ? (
                    <p className="text-xs text-slate-500">
                      No matching verified chunks found in Knowledge Base.
                    </p>
                  ) : (
                    <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-300 list-disc pl-4">
                      {result.supportingEvidence.map((ev, i) => (
                        <li key={i}>{ev}</li>
                      ))}
                    </ul>
                  )}
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      6. Follow-Up Question
                    </div>
                    <p className="text-xs text-slate-800 dark:text-slate-200 mt-1">
                      {result.followUpQuestion}
                    </p>
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      7. Suggested Next Step
                    </div>
                    <p className="text-xs text-slate-800 dark:text-slate-200 mt-1">
                      {result.suggestedNextStep}
                    </p>
                  </div>
                </div>
              </div>

              {result.missingKnowledgeGap && (
                <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2 text-xs text-amber-800 dark:text-amber-200">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-500" />
                    <div>
                      <span className="font-semibold">Missing Verified Knowledge: </span>
                      {result.missingKnowledgeGap}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => void handleLogGap()}
                    className="px-2.5 py-1 rounded bg-amber-600 text-white text-xs font-medium whitespace-nowrap cursor-pointer"
                  >
                    Log Gap
                  </button>
                </div>
              )}

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                <div className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Alternative Response Styles
                </div>
                <div className="space-y-2.5">
                  {result.alternativeResponses.map((alt, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50"
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-xs font-medium text-sky-600 dark:text-sky-400">
                          {alt.style}
                        </span>
                        <div className="flex items-center gap-3 shrink-0">
                          <a
                            href={buildWhatsAppUrl(alt.response, selectedProspect?.contactDetails)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 hover:underline whitespace-nowrap"
                          >
                            <MessageCircle className="w-3 h-3" />
                            <span>WhatsApp</span>
                          </a>
                          <button
                            type="button"
                            onClick={() => void copyText(`alt-${idx}`, alt.response)}
                            className="text-xs text-slate-500 hover:text-sky-500 cursor-pointer whitespace-nowrap"
                          >
                            {copiedKey === `alt-${idx}` ? 'Copied' : 'Copy'}
                          </button>
                        </div>
                      </div>
                      <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                        {alt.response}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
