import {
  Check,
  Copy,
  ImagePlus,
  MessageCircle,
  Plus,
  Send,
  ThumbsDown,
  ThumbsUp,
  Trash2,
  UserPlus,
  X,
} from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import { apiPostJson, apiStreamLiveAssist } from '../../services/apiClient';
import {
  addConversationMessage,
  createConversation,
  linkConversationProspect,
  recordFeedback,
  recordSalesOutcome,
  saveProspect,
  subscribeConversationMessages,
  updateConversationStatus,
} from '../../services/firestoreService';
import type {
  CommunicationChannel,
  CommunicationStyle,
  ConversationMessage,
  FeedbackType,
  ProspectExtractionResult,
  ProspectRecord,
  SalesOutcomeRecord,
} from '../../types';
import { buildWhatsAppUrl, extractBestResponseText } from '../../utils/whatsapp';
import { VoiceRecorderButton } from '../VoiceRecorderButton';

const CHANNELS: CommunicationChannel[] = [
  'WhatsApp',
  'Telephone call',
  'Email',
  'Face-to-face',
  'Social media',
];

const STYLES: CommunicationStyle[] = [
  'Natural',
  'Confident',
  'Persuasive',
  'Professional',
  'Friendly',
  'Direct',
  'Short',
  'Detailed',
];

const NEGATIVE_FEEDBACK_OPTIONS: FeedbackType[] = [
  'Not helpful',
  'Too long',
  'Too robotic',
  'Too aggressive',
  'Factually incorrect',
  'Better alternative',
];

function computeFutureIsoDate(days: number): string {
  if (!days || days <= 0) return '';
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export function LiveSalesAssistantModule() {
  const {
    firebaseUser,
    workspaceId,
    isOnline,
    thinkingMode,
    communicationStyle,
    conversations,
    prospects,
    activeConversationId,
    setActiveConversationId,
    draftProspectId,
    setDraftProspectId,
    buildAiContext,
    notify,
  } = useSalesOs();

  const [channel, setChannel] = useState<CommunicationChannel>('WhatsApp');
  const [style, setStyle] = useState<CommunicationStyle>(communicationStyle);
  const [selectedProspectId, setSelectedProspectId] = useState<string>('');
  const [responseOnly, setResponseOnly] = useState(false);
  const [inputText, setInputText] = useState('');
  const [imageAttachment, setImageAttachment] = useState<{
    mimeType: string;
    dataBase64: string;
    fileName: string;
  } | null>(null);

  const [messages, setMessages] = useState<ConversationMessage[]>([]);
  const [streamingText, setStreamingText] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Inline feedback drawer state
  const [feedbackTargetMsgId, setFeedbackTargetMsgId] = useState<string | null>(null);
  const [feedbackType, setFeedbackType] = useState<FeedbackType>('Too long');
  const [feedbackComment, setFeedbackComment] = useState('');

  // Outcome modal state
  const [showOutcomeForm, setShowOutcomeForm] = useState(false);
  const [outcomeType, setOutcomeType] =
    useState<SalesOutcomeRecord['outcomeType']>('follow_up_scheduled');
  const [outcomeProduct, setOutcomeProduct] = useState('');
  const [outcomeValue, setOutcomeValue] = useState('0');
  const [outcomeStrategy, setOutcomeStrategy] = useState('');
  const [outcomeObjection, setOutcomeObjection] = useState('');
  const [outcomeNotes, setOutcomeNotes] = useState('');

  // Automated Prospect Extraction drawer state
  const [extractingProspect, setExtractingProspect] = useState(false);
  const [savingProspect, setSavingProspect] = useState(false);
  const [extractedDraft, setExtractedDraft] = useState<{
    displayName: string;
    contactDetails: string;
    tradingExperience: string;
    previousPropFirm: string;
    preferredChallenge: string;
    preferredAccountSize: string;
    primaryConcern: string;
    objections: string;
    buyingSignals: string;
    status: ProspectRecord['status'];
    followUpDate: string;
    verifiedNotes: string;
    aiObservations: string;
    updateLinked: boolean;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const threadEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setStyle(communicationStyle);
  }, [communicationStyle]);

  useEffect(() => {
    if (draftProspectId) {
      setSelectedProspectId(draftProspectId);
      setDraftProspectId(null);
    }
  }, [draftProspectId, setDraftProspectId]);

  useEffect(() => {
    if (!activeConversationId || !firebaseUser) {
      setMessages([]);
      return;
    }
    const conv = conversations.find((c) => c.conversationId === activeConversationId);
    if (conv) {
      setChannel(conv.channel);
      setSelectedProspectId(conv.prospectId || '');
    }
    const unsub = subscribeConversationMessages(activeConversationId, firebaseUser.uid, setMessages);
    return () => unsub();
  }, [activeConversationId, firebaseUser, conversations]);

  useEffect(() => {
    threadEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, streamingText]);

  const linkedProspect = prospects.find((p) => p.prospectId === selectedProspectId) ?? null;

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      notify('Please upload a PNG, JPG, or WEBP screenshot.', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      const base64 = result.split(',')[1] || '';
      setImageAttachment({
        mimeType: file.type,
        dataBase64: base64,
        fileName: file.name,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !workspaceId) return;
    if (!isOnline) {
      notify('Offline Field Mode: Live AI requires a network connection.', 'error');
      return;
    }
    const prompt = inputText.trim();
    if (!prompt && !imageAttachment) return;

    const effectivePrompt =
      prompt || 'Analyse the attached customer conversation screenshot and draft the best next response.';

    setIsStreaming(true);
    setStreamingText('');

    try {
      let convId = activeConversationId;
      if (!convId) {
        const title =
          (linkedProspect ? `${linkedProspect.displayName}: ` : '') +
          effectivePrompt.slice(0, 60);
        convId = await createConversation({
          userId: firebaseUser.uid,
          workspaceId,
          title,
          channel,
          mode: thinkingMode,
          module: 'live_assistant',
          prospectId: selectedProspectId || undefined,
        });
        setActiveConversationId(convId);
      }

      await addConversationMessage({
        conversationId: convId,
        userId: firebaseUser.uid,
        role: 'user',
        content: imageAttachment
          ? `${effectivePrompt}\n[Attached screenshot: ${imageAttachment.fileName}]`
          : effectivePrompt,
        mode: thinkingMode,
      });

      const ctx = buildAiContext(effectivePrompt, linkedProspect);
      const historyPayload = messages.slice(-10).map((m) => ({
        role: (m.role === 'assistant' ? 'assistant' : 'user') as 'user' | 'assistant',
        content: m.content,
      }));

      setInputText('');
      const pendingImg = imageAttachment;
      setImageAttachment(null);

      let accumulated = '';
      const meta = await apiStreamLiveAssist(
        {
          prompt: effectivePrompt,
          channel,
          style,
          responseOnly,
          history: historyPayload,
          imageAttachment: pendingImg
            ? { mimeType: pendingImg.mimeType, dataBase64: pendingImg.dataBase64 }
            : undefined,
          context: ctx,
        },
        (chunk) => {
          accumulated += chunk;
          setStreamingText(accumulated);
        },
      );

      const citations = ctx.knowledgeChunks.map(
        (c) => `${c.sourceTitle} (v${c.documentVersion})`,
      );

      await addConversationMessage({
        conversationId: convId,
        userId: firebaseUser.uid,
        role: 'assistant',
        content: accumulated || 'No response generated.',
        mode: meta.resolvedMode,
        sourceReferences: Array.from(new Set(citations)),
        tokenUsage: meta.tokenUsage,
        responseLatency: meta.latencyMs,
      });
      setStreamingText('');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to generate response.';
      notify(msg, 'error');
    } finally {
      setIsStreaming(false);
    }
  };

  const handleExtractProspect = async () => {
    const transcriptLines = messages.map(
      (m) => `${m.role === 'assistant' ? 'Assistant Suggestion' : 'Executive / Prospect'}: ${m.content}`,
    );
    if (inputText.trim()) {
      transcriptLines.push(`Draft Note: ${inputText.trim()}`);
    }
    const combined = transcriptLines.join('\n\n').trim();
    if (!combined) {
      notify('Add or send a message first before extracting a prospect profile.', 'error');
      return;
    }
    if (!isOnline) {
      notify('Offline Field Mode: Prospect extraction requires network access.', 'error');
      return;
    }

    setExtractingProspect(true);
    try {
      const ctx = buildAiContext(combined, linkedProspect);
      const res = await apiPostJson<{ data: ProspectExtractionResult }>('/api/ai/extract-prospect', {
        conversationText: combined,
        channel,
        existingProspectName: linkedProspect?.displayName || '',
        context: ctx,
      });
      const d = res.data;
      setExtractedDraft({
        displayName: linkedProspect?.displayName || d.displayName || `${channel} Prospect`,
        contactDetails: linkedProspect?.contactDetails || d.contactDetails || '',
        tradingExperience: d.tradingExperience || linkedProspect?.tradingExperience || '',
        previousPropFirm: d.previousPropFirm || linkedProspect?.previousPropFirm || '',
        preferredChallenge: d.preferredChallenge || linkedProspect?.preferredChallenge || '',
        preferredAccountSize: d.preferredAccountSize || linkedProspect?.preferredAccountSize || '',
        primaryConcern: d.primaryConcern || linkedProspect?.primaryConcern || '',
        objections: d.objections.join(', '),
        buyingSignals: d.buyingSignals.join(', '),
        status: d.suggestedStatus || 'qualified',
        followUpDate:
          computeFutureIsoDate(d.suggestedFollowUpDays) || linkedProspect?.followUpDate || '',
        verifiedNotes: d.verifiedNotes || '',
        aiObservations: d.aiObservations || '',
        updateLinked: Boolean(linkedProspect),
      });
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Prospect extraction failed.', 'error');
    } finally {
      setExtractingProspect(false);
    }
  };

  const handleSaveExtractedProspect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !workspaceId || !extractedDraft?.displayName.trim()) return;
    setSavingProspect(true);
    try {
      const targetId =
        extractedDraft.updateLinked && linkedProspect ? linkedProspect.prospectId : undefined;

      const mergedVerifiedNotes =
        targetId && linkedProspect?.verifiedNotes
          ? `${linkedProspect.verifiedNotes}\n---\n${extractedDraft.verifiedNotes}`.trim()
          : extractedDraft.verifiedNotes;

      const savedId = await saveProspect({
        prospectId: targetId,
        userId: firebaseUser.uid,
        workspaceId,
        displayName: extractedDraft.displayName,
        contactDetails: extractedDraft.contactDetails,
        tradingExperience: extractedDraft.tradingExperience,
        previousPropFirm: extractedDraft.previousPropFirm,
        preferredChallenge: extractedDraft.preferredChallenge,
        preferredAccountSize: extractedDraft.preferredAccountSize,
        primaryConcern: extractedDraft.primaryConcern,
        objections: extractedDraft.objections
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
        buyingSignals: extractedDraft.buyingSignals
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
        verifiedNotes: mergedVerifiedNotes,
        aiObservations: extractedDraft.aiObservations,
        followUpDate: extractedDraft.followUpDate,
        status: extractedDraft.status,
      });

      setSelectedProspectId(savedId);
      if (activeConversationId) {
        await linkConversationProspect(activeConversationId, savedId);
      }
      setExtractedDraft(null);
      notify(
        targetId
          ? 'Linked prospect profile updated from live chat.'
          : 'New prospect profile extracted and linked to this thread.',
        'success',
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save prospect profile.', 'error');
    } finally {
      setSavingProspect(false);
    }
  };

  const handleCopy = async (id: string, text: string) => {
    const copyVal = extractBestResponseText(text);
    await navigator.clipboard.writeText(copyVal);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handlePositiveFeedback = async (msgId: string, type: FeedbackType) => {
    if (!firebaseUser || !activeConversationId) return;
    try {
      await recordFeedback({
        userId: firebaseUser.uid,
        conversationId: activeConversationId,
        messageId: msgId,
        rating: 'positive',
        feedbackType: type,
        comment: '',
      });
      notify(`Recorded "${type}" feedback for Layer 2 learning.`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save feedback.', 'error');
    }
  };

  const handleNegativeFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !activeConversationId || !feedbackTargetMsgId) return;
    try {
      await recordFeedback({
        userId: firebaseUser.uid,
        conversationId: activeConversationId,
        messageId: feedbackTargetMsgId,
        rating: 'negative',
        feedbackType,
        comment: feedbackComment,
      });
      setFeedbackTargetMsgId(null);
      setFeedbackComment('');
      notify('Negative feedback logged. Future instructions will adapt.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save feedback.', 'error');
    }
  };

  const handleSaveOutcome = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser) return;
    try {
      await recordSalesOutcome({
        userId: firebaseUser.uid,
        prospectId: selectedProspectId || undefined,
        conversationId: activeConversationId || undefined,
        outcomeType,
        product: outcomeProduct || 'Thaurus Guru Challenge',
        salesValue: Number(outcomeValue) || 0,
        currency: 'USD',
        strategyUsed: outcomeStrategy || `${channel} · ${style}`,
        blockingObjection: outcomeObjection,
        outcomeNotes,
      });
      if (activeConversationId) {
        await updateConversationStatus(activeConversationId, {
          status:
            outcomeType === 'purchased'
              ? 'converted'
              : outcomeType === 'declined'
                ? 'closed_lost'
                : 'follow_up',
          outcome: outcomeType,
        });
      }
      setShowOutcomeForm(false);
      setOutcomeNotes('');
      setOutcomeObjection('');
      notify('Sales outcome recorded to Layer 3 Performance Learning.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to record outcome.', 'error');
    }
  };

  const canExtract = messages.length > 0 || inputText.trim().length > 0;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-[calc(100vh-7.5rem)] min-h-[600px]">
      {/* Left Thread & Controls Column */}
      <div className="lg:col-span-4 xl:col-span-3 flex flex-col gap-3 overflow-y-auto pr-1">
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
              Session Controls
            </h2>
            <button
              type="button"
              onClick={() => {
                setActiveConversationId(null);
                setMessages([]);
                setExtractedDraft(null);
              }}
              className="inline-flex items-center gap-1 text-xs font-medium text-sky-600 dark:text-sky-400 hover:underline cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Thread</span>
            </button>
          </div>

          <div>
            <label className="block text-xs text-slate-500 dark:text-slate-400 mb-1">
              Linked Prospect
            </label>
            <select
              value={selectedProspectId}
              onChange={(e) => setSelectedProspectId(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-900 dark:text-white"
            >
              <option value="">General Prospect (Unlinked)</option>
              {prospects.map((p) => (
                <option key={p.prospectId} value={p.prospectId}>
                  {p.displayName} ({p.preferredChallenge || p.status})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs text-slate-500 dark:text-slate-400 mb-1">
                Channel
              </label>
              <select
                value={channel}
                onChange={(e) => setChannel(e.target.value as CommunicationChannel)}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-900 dark:text-white"
              >
                {CHANNELS.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-slate-500 dark:text-slate-400 mb-1">
                Response Style
              </label>
              <select
                value={style}
                onChange={(e) => setStyle(e.target.value as CommunicationStyle)}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-900 dark:text-white"
              >
                {STYLES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer pt-1">
            <input
              type="checkbox"
              checked={responseOnly}
              onChange={(e) => setResponseOnly(e.target.checked)}
              className="rounded border-slate-300 dark:border-slate-700 accent-sky-600"
            />
            <span>Return exact response only (no coaching notes)</span>
          </label>

          <button
            type="button"
            disabled={!canExtract || extractingProspect || !isOnline}
            onClick={() => void handleExtractProspect()}
            className="w-full py-2 px-3 rounded-lg bg-sky-600/12 text-sky-600 dark:text-sky-400 hover:bg-sky-600/20 disabled:opacity-50 text-xs font-medium inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5 shrink-0" />
            <span>
              {extractingProspect ? 'Extracting Profile...' : 'Extract to Prospect Profile'}
            </span>
          </button>

          {activeConversationId && (
            <button
              type="button"
              onClick={() => setShowOutcomeForm((v) => !v)}
              className="w-full py-2 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Record Sales Outcome (Layer 3)
            </button>
          )}
        </div>

        {/* Recent Threads */}
        <div className="flex-1 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] overflow-y-auto">
          <h3 className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2.5">
            Recent Threads
          </h3>
          {conversations.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Your live assistant sessions will appear here automatically.
            </p>
          ) : (
            <div className="space-y-1">
              {conversations.slice(0, 20).map((c) => (
                <button
                  key={c.conversationId}
                  type="button"
                  onClick={() => setActiveConversationId(c.conversationId)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-colors cursor-pointer ${
                    activeConversationId === c.conversationId
                      ? 'bg-sky-600/12 text-sky-600 dark:text-sky-400 font-medium'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="truncate">{c.title}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1.5">
                    <span>{c.channel}</span>
                    <span>·</span>
                    <span className="capitalize">{c.status.replace('_', ' ')}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main Live Conversation Workspace */}
      <div className="lg:col-span-8 xl:col-span-9 flex flex-col rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] overflow-hidden">
        {/* Automated Prospect Extraction Review Drawer */}
        {extractedDraft && (
          <form
            onSubmit={handleSaveExtractedProspect}
            className="p-4 border-b border-sky-500/30 bg-sky-500/5 space-y-3 overflow-y-auto max-h-80"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-semibold text-slate-900 dark:text-white">
                  Confirm Extracted Prospect Profile
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Verified facts and AI-inferred observations are separated before saving to Firestore.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setExtractedDraft(null)}
                className="p-1 text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                aria-label="Close extraction review"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
              <input
                required
                type="text"
                value={extractedDraft.displayName}
                onChange={(e) =>
                  setExtractedDraft({ ...extractedDraft, displayName: e.target.value })
                }
                placeholder="Prospect Name"
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
              <input
                type="text"
                value={extractedDraft.contactDetails}
                onChange={(e) =>
                  setExtractedDraft({ ...extractedDraft, contactDetails: e.target.value })
                }
                placeholder="WhatsApp / Phone / Email"
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
              <input
                type="text"
                value={extractedDraft.preferredChallenge}
                onChange={(e) =>
                  setExtractedDraft({ ...extractedDraft, preferredChallenge: e.target.value })
                }
                placeholder="Challenge Interest"
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
              <input
                type="text"
                value={extractedDraft.preferredAccountSize}
                onChange={(e) =>
                  setExtractedDraft({ ...extractedDraft, preferredAccountSize: e.target.value })
                }
                placeholder="Account Size"
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              <input
                type="text"
                value={extractedDraft.primaryConcern}
                onChange={(e) =>
                  setExtractedDraft({ ...extractedDraft, primaryConcern: e.target.value })
                }
                placeholder="Primary Concern"
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
              <select
                value={extractedDraft.status}
                onChange={(e) =>
                  setExtractedDraft({
                    ...extractedDraft,
                    status: e.target.value as ProspectRecord['status'],
                  })
                }
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              >
                <option value="new">New</option>
                <option value="contacted">Contacted</option>
                <option value="qualified">Qualified</option>
                <option value="follow_up">Follow-Up</option>
                <option value="converted">Converted</option>
                <option value="declined">Declined</option>
              </select>
              <input
                type="date"
                value={extractedDraft.followUpDate}
                onChange={(e) =>
                  setExtractedDraft({ ...extractedDraft, followUpDate: e.target.value })
                }
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <textarea
                rows={2}
                value={extractedDraft.verifiedNotes}
                onChange={(e) =>
                  setExtractedDraft({ ...extractedDraft, verifiedNotes: e.target.value })
                }
                placeholder="Verified facts stated in chat..."
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
              <textarea
                rows={2}
                value={extractedDraft.aiObservations}
                onChange={(e) =>
                  setExtractedDraft({ ...extractedDraft, aiObservations: e.target.value })
                }
                placeholder="AI confidence-rated observations..."
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2">
              {linkedProspect ? (
                <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={extractedDraft.updateLinked}
                    onChange={(e) =>
                      setExtractedDraft({ ...extractedDraft, updateLinked: e.target.checked })
                    }
                    className="accent-sky-600"
                  />
                  <span>Update linked prospect ({linkedProspect.displayName})</span>
                </label>
              ) : (
                <span className="text-[11px] text-slate-500">
                  Will create a new prospect record and link it to this conversation.
                </span>
              )}
              <button
                type="submit"
                disabled={savingProspect}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium whitespace-nowrap cursor-pointer"
              >
                {savingProspect ? 'Saving...' : 'Save & Link Prospect'}
              </button>
            </div>
          </form>
        )}

        {/* Outcome Drawer */}
        {showOutcomeForm && (
          <form
            onSubmit={handleSaveOutcome}
            className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/70 space-y-3"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold text-slate-900 dark:text-white">
                Record Real-World Outcome
              </h3>
              <button
                type="button"
                onClick={() => setShowOutcomeForm(false)}
                className="text-xs text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                Close
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
              <select
                value={outcomeType}
                onChange={(e) =>
                  setOutcomeType(e.target.value as SalesOutcomeRecord['outcomeType'])
                }
                className="px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
              >
                <option value="replied">Prospect Replied</option>
                <option value="meeting_secured">Meeting / Call Secured</option>
                <option value="purchased">Challenge Purchased</option>
                <option value="follow_up_scheduled">Follow-Up Scheduled</option>
                <option value="declined">Declined</option>
              </select>
              <input
                type="text"
                value={outcomeProduct}
                onChange={(e) => setOutcomeProduct(e.target.value)}
                placeholder="Product / Challenge (e.g. $50k 2-Step)"
                className="px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
              />
              <input
                type="number"
                min="0"
                value={outcomeValue}
                onChange={(e) => setOutcomeValue(e.target.value)}
                placeholder="Value (USD)"
                className="px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono"
              />
              <input
                type="text"
                value={outcomeObjection}
                onChange={(e) => setOutcomeObjection(e.target.value)}
                placeholder="Blocking objection (if any)"
                className="px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
              />
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={outcomeStrategy}
                onChange={(e) => setOutcomeStrategy(e.target.value)}
                placeholder="Strategy used (e.g. Trust + Payout Proof)"
                className="flex-1 px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
              />
              <input
                type="text"
                value={outcomeNotes}
                onChange={(e) => setOutcomeNotes(e.target.value)}
                placeholder="Outcome notes..."
                className="flex-1 px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium whitespace-nowrap cursor-pointer"
              >
                Save Outcome
              </button>
            </div>
          </form>
        )}

        {/* Message Feed */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-5">
          {messages.length === 0 && !streamingText ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-lg mx-auto py-10">
              <h3 className="text-base font-semibold text-slate-900 dark:text-white mb-2">
                Live Sales Co-Pilot Ready
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
                Paste a prospect&apos;s WhatsApp message, speak a live call summary with the
                microphone button, or attach a conversation screenshot.
              </p>
              <div className="text-xs text-slate-500 dark:text-slate-400 flex flex-wrap justify-center gap-2">
                <span>Active channel: {channel}</span>
                <span>·</span>
                <span>Style: {style}</span>
                <span>·</span>
                <span>Thinking: {thinkingMode}</span>
              </div>
            </div>
          ) : (
            messages.map((m) => {
              const bestResponse = extractBestResponseText(m.content);
              const waHref = buildWhatsAppUrl(bestResponse, linkedProspect?.contactDetails);

              return (
                <div
                  key={m.messageId}
                  className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-3xl rounded-xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                      m.role === 'user'
                        ? 'bg-sky-600 text-white'
                        : 'border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/70 text-slate-900 dark:text-slate-100 w-full'
                    }`}
                  >
                    {m.content}

                    {m.role === 'assistant' && (
                      <div className="mt-3 pt-2.5 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <div className="flex flex-wrap items-center gap-2 font-mono">
                          <span className="capitalize">{m.mode} mode</span>
                          {m.responseLatency > 0 && (
                            <>
                              <span>·</span>
                              <span>{m.responseLatency}ms</span>
                            </>
                          )}
                          {m.sourceReferences.length > 0 && (
                            <>
                              <span>·</span>
                              <span>Sources: {m.sourceReferences.join(', ')}</span>
                            </>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            type="button"
                            onClick={() => void handleCopy(m.messageId, m.content)}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-200/60 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 cursor-pointer whitespace-nowrap"
                          >
                            {copiedId === m.messageId ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-500" />
                                <span>Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>Copy Response</span>
                              </>
                            )}
                          </button>

                          <a
                            href={waHref}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-medium transition-colors whitespace-nowrap"
                            title={
                              linkedProspect?.contactDetails
                                ? `Launch WhatsApp to ${linkedProspect.displayName}`
                                : 'Open in WhatsApp with pre-filled response'
                            }
                          >
                            <MessageCircle className="w-3 h-3" />
                            <span>WhatsApp</span>
                          </a>

                          <button
                            type="button"
                            onClick={() => void handlePositiveFeedback(m.messageId, 'Helpful')}
                            className="p-1.5 rounded border border-slate-200 dark:border-slate-700 hover:text-emerald-500 cursor-pointer"
                            title="Helpful"
                          >
                            <ThumbsUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              void handlePositiveFeedback(m.messageId, 'Good closing approach')
                            }
                            className="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 hover:text-emerald-500 cursor-pointer whitespace-nowrap"
                          >
                            Good close
                          </button>
                          <button
                            type="button"
                            onClick={() => setFeedbackTargetMsgId(m.messageId)}
                            className="p-1.5 rounded border border-slate-200 dark:border-slate-700 hover:text-red-500 cursor-pointer"
                            title="Report weakness"
                          >
                            <ThumbsDown className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {feedbackTargetMsgId === m.messageId && (
                    <form
                      onSubmit={handleNegativeFeedbackSubmit}
                      className="mt-2 p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 w-full max-w-xl space-y-2"
                    >
                      <div className="flex flex-wrap gap-1.5">
                        {NEGATIVE_FEEDBACK_OPTIONS.map((opt) => (
                          <button
                            key={opt}
                            type="button"
                            onClick={() => setFeedbackType(opt)}
                            className={`px-2.5 py-1 rounded text-xs cursor-pointer ${
                              feedbackType === opt
                                ? 'bg-red-600 text-white'
                                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                            }`}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={feedbackComment}
                          onChange={(e) => setFeedbackComment(e.target.value)}
                          placeholder="Optional: what should have been different?"
                          className="flex-1 px-2.5 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent text-xs"
                        />
                        <button
                          type="submit"
                          className="px-3 py-1.5 rounded bg-sky-600 text-white text-xs font-medium cursor-pointer"
                        >
                          Save
                        </button>
                        <button
                          type="button"
                          onClick={() => setFeedbackTargetMsgId(null)}
                          className="px-2.5 py-1.5 rounded text-xs text-slate-500"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              );
            })
          )}

          {streamingText && (
            <div className="max-w-3xl rounded-xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap border border-sky-500/40 bg-slate-50 dark:bg-slate-900/70 text-slate-900 dark:text-slate-100">
              {streamingText}
            </div>
          )}
          <div ref={threadEndRef} />
        </div>

        {/* Input Composer */}
        <form
          onSubmit={handleSend}
          className="p-3 lg:p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#0A0F1C] space-y-2"
        >
          {imageAttachment && (
            <div className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-sky-500/10 border border-sky-500/30 text-xs text-sky-600 dark:text-sky-300">
              <span>Screenshot attached: {imageAttachment.fileName}</span>
              <button
                type="button"
                onClick={() => setImageAttachment(null)}
                className="text-slate-500 hover:text-red-500 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          <div className="flex items-end gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
              title="Attach conversation screenshot"
            >
              <ImagePlus className="w-4 h-4" />
            </button>

            <VoiceRecorderButton
              disabled={isStreaming || !isOnline}
              contextHint={`Live ${channel} sales conversation`}
              onTranscript={(text) => {
                setInputText((prev) => (prev.trim() ? `${prev.trim()} ${text}` : text));
                notify('Voice note transcribed via Gemini.', 'success');
              }}
              onError={(msg) => notify(msg, 'error')}
            />

            <textarea
              rows={2}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  void handleSend(e);
                }
              }}
              placeholder="Paste customer message, speak live call summary, or ask for next reply..."
              className="flex-1 resize-none rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500/40"
            />

            <button
              type="submit"
              disabled={isStreaming || !isOnline || (!inputText.trim() && !imageAttachment)}
              className="px-4 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-sm font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 whitespace-nowrap"
            >
              <Send className="w-4 h-4" />
              <span>{isStreaming ? 'Thinking...' : 'Generate'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
