import { Check, Copy, MessageCircle, Target } from 'lucide-react';
import React, { useState } from 'react';
import { useSalesOs } from '../../context/SalesOsContext';
import { apiPostJson } from '../../services/apiClient';
import type { ClosingAnalysisResult } from '../../types';
import { buildWhatsAppUrl } from '../../utils/whatsapp';

export function ClosingIntelligenceModule() {
  const { prospects, buildAiContext, notify } = useSalesOs();
  const [prospectId, setProspectId] = useState('');
  const [goal, setGoal] = useState('Secure challenge registration without artificial pressure');
  const [conversationText, setConversationText] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ClosingAnalysisResult | null>(null);
  const [copied, setCopied] = useState(false);

  const selectedProspect = prospects.find((p) => p.prospectId === prospectId) ?? null;

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!conversationText.trim()) return;
    setLoading(true);
    try {
      const ctx = buildAiContext(conversationText, selectedProspect);
      const res = await apiPostJson<{ data: ClosingAnalysisResult }>('/api/ai/closing', {
        conversationText,
        goal,
        context: ctx,
      });
      setResult(res.data);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Closing analysis failed.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyScript = async () => {
    if (!result) return;
    await navigator.clipboard.writeText(result.closeScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
          Closing Intelligence
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          Assess buying signals, remaining concerns, and product suitability to select the highest
          integrity closing technique.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <form
          onSubmit={handleAnalyze}
          className="lg:col-span-5 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-4"
        >
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Linked Prospect (Optional)
            </label>
            <select
              value={prospectId}
              onChange={(e) => setProspectId(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
            >
              <option value="">General Prospect</option>
              {prospects.map((p) => (
                <option key={p.prospectId} value={p.prospectId}>
                  {p.displayName} ({p.preferredChallenge || p.status})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Target Outcome
            </label>
            <input
              type="text"
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Paste Conversation or Deal Summary
            </label>
            <textarea
              rows={8}
              value={conversationText}
              onChange={(e) => setConversationText(e.target.value)}
              placeholder="Paste the back-and-forth conversation with the trader..."
              className="w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3 py-2 text-sm"
            />
          </div>

          <button
            type="submit"
            disabled={loading || !conversationText.trim()}
            className="w-full py-2.5 px-4 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-sm font-medium cursor-pointer"
          >
            {loading ? 'Evaluating Readiness...' : 'Evaluate Closing Strategy'}
          </button>
        </form>

        <div className="lg:col-span-7">
          {!result ? (
            <div className="p-10 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] text-center">
              <Target className="w-8 h-8 text-sky-500 mx-auto mb-3" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Closing Readiness &amp; Recommendation
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
                Evaluates Summary, Alternative-choice, Assumptive, Clarification, Commitment-based,
                and Next-step closes without artificial urgency.
              </p>
            </div>
          ) : (
            <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1322] space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <div className="text-xs text-slate-500">Recommended Close Technique</div>
                  <div className="text-lg font-semibold text-sky-600 dark:text-sky-400 mt-0.5">
                    {result.recommendedCloseType}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-500">Conversion Readiness</div>
                  <div className="text-xl font-mono font-semibold tabular-nums text-slate-900 dark:text-white">
                    {result.readinessScore}/100 · {result.readinessLabel}
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Exact Closing Script
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <a
                      href={buildWhatsAppUrl(result.closeScript, selectedProspect?.contactDetails)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 hover:underline whitespace-nowrap"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => void handleCopyScript()}
                      className="inline-flex items-center gap-1 text-xs text-sky-600 dark:text-sky-400 cursor-pointer whitespace-nowrap"
                    >
                      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Copied' : 'Copy Script'}</span>
                    </button>
                  </div>
                </div>
                <p className="text-sm text-slate-900 dark:text-slate-100 leading-relaxed p-3.5 rounded-lg bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800">
                  {result.closeScript}
                </p>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-2">
                  <span className="font-semibold">Why this fits: </span>
                  {result.rationale}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-200 dark:border-slate-800">
                <div>
                  <div className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 mb-1.5">
                    Buying Signals Detected
                  </div>
                  <ul className="space-y-1 text-xs text-slate-700 dark:text-slate-300 list-disc pl-4">
                    {result.buyingSignals.map((s, i) => (
                      <li key={i}>{s}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1.5">
                    Remaining Concerns
                  </div>
                  <ul className="space-y-1 text-xs text-slate-700 dark:text-slate-300 list-disc pl-4">
                    {result.remainingConcerns.map((c, i) => (
                      <li key={i}>{c}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-xs">
                <div>
                  <div className="text-slate-500 font-medium">Purchase Motivation</div>
                  <div className="text-slate-800 dark:text-slate-200 mt-1">
                    {result.purchaseMotivation}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500 font-medium">Product Suitability</div>
                  <div className="text-slate-800 dark:text-slate-200 mt-1">
                    {result.productSuitability}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500 font-medium">Genuine Urgency</div>
                  <div className="text-slate-800 dark:text-slate-200 mt-1">
                    {result.genuineUrgency}
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300">
                  Next-Step Fallback if Not Ready:{' '}
                </span>
                <span className="text-slate-600 dark:text-slate-400">
                  {result.followUpFallback}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
