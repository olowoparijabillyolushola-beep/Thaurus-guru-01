import {
  Activity,
  BarChart3,
  BookOpen,
  Brain,
  ChevronRight,
  Compass,
  Database,
  History,
  LogOut,
  Menu,
  MessageSquare,
  Moon,
  PhoneCall,
  Settings,
  ShieldAlert,
  Sun,
  Target,
  Users,
  X,
} from 'lucide-react';
import React, { useState } from 'react';
import { useSalesOs } from '../context/SalesOsContext';
import type { NavSection, ThinkingMode } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface NavItem {
  id: NavSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  group: 'Operations' | 'Intelligence' | 'System';
}

export const NAV_ITEMS: NavItem[] = [
  { id: 'overview', label: 'Overview', icon: Activity, group: 'Operations' },
  { id: 'live_assistant', label: 'Live Sales Assistant', icon: MessageSquare, group: 'Operations' },
  { id: 'objections', label: 'Objection Intelligence', icon: ShieldAlert, group: 'Operations' },
  { id: 'closing', label: 'Closing Intelligence', icon: Target, group: 'Operations' },
  { id: 'cold_call', label: 'Cold Call Studio', icon: PhoneCall, group: 'Operations' },
  { id: 'product', label: 'Product Intelligence', icon: Compass, group: 'Intelligence' },
  { id: 'prospects', label: 'Prospect Intelligence', icon: Users, group: 'Intelligence' },
  { id: 'simulation', label: 'Sales Simulation', icon: Brain, group: 'Intelligence' },
  { id: 'history', label: 'Conversation History', icon: History, group: 'Intelligence' },
  { id: 'knowledge', label: 'Knowledge Base', icon: Database, group: 'System' },
  { id: 'learning', label: 'Learning Centre', icon: BookOpen, group: 'System' },
  { id: 'analytics', label: 'Performance Analytics', icon: BarChart3, group: 'System' },
  { id: 'settings', label: 'Settings', icon: Settings, group: 'System' },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const {
    profile,
    activeNav,
    setActiveNav,
    thinkingMode,
    setThinkingMode,
    theme,
    toggleTheme,
    logout,
    currentInstructionVersion,
  } = useSalesOs();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const activeItem = NAV_ITEMS.find((n) => n.id === activeNav) ?? NAV_ITEMS[0];

  const handleSelectNav = (id: NavSection) => {
    setActiveNav(id);
    setMobileMenuOpen(false);
  };

  const renderNavGroups = () => (
    <div className="space-y-6 px-3 py-4">
      {(['Operations', 'Intelligence', 'System'] as const).map((group) => (
        <div key={group}>
          <div className="px-3 mb-2 text-xs font-medium text-slate-400 dark:text-slate-500">
            {group}
          </div>
          <div className="space-y-0.5">
            {NAV_ITEMS.filter((item) => item.group === group).map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSelectNav(item.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors text-left cursor-pointer ${
                    isActive
                      ? 'bg-sky-600/12 text-sky-600 dark:text-sky-400 font-medium'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-[#070B14] text-slate-900 dark:text-slate-100">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-[260px] lg:shrink-0 lg:flex-col border-r border-slate-200 dark:border-slate-800/90 bg-white dark:bg-[#0A0F1C]">
        <div className="h-14 px-5 flex items-center border-b border-slate-200 dark:border-slate-800/90">
          <span className="font-display text-base font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
            Thaurus Guru
          </span>
        </div>

        <div className="flex-1 overflow-y-auto">{renderNavGroups()}</div>

        <div className="p-4 border-t border-slate-200 dark:border-slate-800/90 space-y-3">
          <div className="text-xs text-slate-500 dark:text-slate-400 space-y-0.5">
            <div className="font-medium text-slate-800 dark:text-slate-200 truncate">
              {profile?.displayName || 'Sales Executive'}
            </div>
            <div className="flex items-center gap-1.5 truncate">
              <span className="capitalize">{profile?.role?.replace('_', ' ') || 'Executive'}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono">v{currentInstructionVersion}</span>
            </div>
          </div>
          <PWAInstallButton variant="sidebar" />
          <button
            type="button"
            onClick={() => void logout()}
            className="w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign out</span>
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/60"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-72 max-w-[85vw] bg-white dark:bg-[#0A0F1C] border-r border-slate-200 dark:border-slate-800 flex flex-col z-10">
            <div className="h-14 px-4 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
              <span className="font-display text-base font-bold text-slate-900 dark:text-white">
                Thaurus Guru
              </span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white"
                aria-label="Close navigation menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">{renderNavGroups()}</div>
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 space-y-2">
              <PWAInstallButton variant="sidebar" />
              <button
                type="button"
                onClick={() => void logout()}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign out</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Shell */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar Contract: Breadcrumb on left, Workspace controls on right */}
        <header className="h-14 shrink-0 border-b border-slate-200 dark:border-slate-800/90 bg-white/95 dark:bg-[#0A0F1C]/95 px-4 lg:px-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 -ml-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-1.5 text-sm min-w-0">
              <span className="hidden sm:inline text-slate-400 dark:text-slate-500 whitespace-nowrap">
                Sales Intelligence OS
              </span>
              <ChevronRight className="hidden sm:inline w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="font-medium text-slate-900 dark:text-white truncate">
                {activeItem.label}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton variant="header" />
            {/* Thinking Mode Segmented Selector */}
            <div
              className="flex items-center p-0.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900"
              role="group"
              aria-label="Intelligence Thinking Mode"
            >
              {(['auto', 'fast', 'deep'] as ThinkingMode[]).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => setThinkingMode(mode)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md capitalize transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    thinkingMode === mode
                      ? 'bg-sky-600 text-white'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={toggleTheme}
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
              title={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </header>

        {/* Active Viewport */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          <div className="max-w-[1360px] mx-auto">{children}</div>
        </main>
      </div>
    </div>
  );
}
