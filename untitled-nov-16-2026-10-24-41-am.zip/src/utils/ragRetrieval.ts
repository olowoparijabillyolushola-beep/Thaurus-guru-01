import type {
  AllowedModel,
  FeedbackRecord,
  KnowledgeChunkRecord,
  KnowledgeSourceRecord,
  LearningRecord,
  ProspectRecord,
  ThinkingMode,
  UserMemoryRecord,
} from '../types';

export interface RetrievedChunkResult {
  sourceTitle: string;
  category: string;
  documentVersion: number;
  sectionTitle: string;
  content: string;
  score: number;
}

export function retrieveRelevantKnowledgeChunks(
  query: string,
  chunks: KnowledgeChunkRecord[],
  sources: KnowledgeSourceRecord[],
  categoryFilter = 'All',
  limit = 6,
): {
  chunks: RetrievedChunkResult[];
  conflicts: string[];
} {
  const approvedSources = new Map<string, KnowledgeSourceRecord>();
  const latestVersionByCategoryTitle = new Map<string, number>();

  for (const src of sources) {
    if (src.approvalStatus === 'approved') {
      approvedSources.set(src.sourceId, src);
      const key = `${src.category}::${src.title.toLowerCase()}`;
      const prev = latestVersionByCategoryTitle.get(key) ?? 0;
      if (src.documentVersion > prev) {
        latestVersionByCategoryTitle.set(key, src.documentVersion);
      }
    }
  }

  const tokens = query
    .toLowerCase()
    .replace(/[^a-z0-9%$₦\s]/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length >= 2);

  const scored: RetrievedChunkResult[] = [];

  for (const chunk of chunks) {
    if (chunk.approvalStatus !== 'approved') continue;
    const parent = approvedSources.get(chunk.sourceId);
    if (!parent) continue;
    if (categoryFilter !== 'All' && chunk.category !== categoryFilter) continue;

    const haystack = `${parent.title} ${chunk.category} ${chunk.sectionTitle} ${chunk.content}`.toLowerCase();
    let score = 0;

    for (const token of tokens) {
      if (haystack.includes(token)) score += 2;
      if (chunk.keywords.some((kw) => kw.toLowerCase().includes(token))) score += 3;
      if (chunk.category.toLowerCase().includes(token)) score += 2;
    }

    // Prefer newer document versions
    score += chunk.documentVersion * 0.5;
    if (tokens.length === 0) {
      score += 1;
    }

    if (score > 0.5 || tokens.length === 0) {
      scored.push({
        sourceTitle: parent.title,
        category: chunk.category,
        documentVersion: chunk.documentVersion,
        sectionTitle: chunk.sectionTitle,
        content: chunk.content,
        score,
      });
    }
  }

  scored.sort((a, b) => b.score - a.score);
  const top = scored.slice(0, limit);

  // Detect multiple distinct versions or sources in same category
  const conflicts: string[] = [];
  const versionsSeenByCat = new Map<string, Set<string>>();
  for (const item of top) {
    const set = versionsSeenByCat.get(item.category) ?? new Set<string>();
    set.add(`${item.sourceTitle} v${item.documentVersion}`);
    versionsSeenByCat.set(item.category, set);
  }
  for (const [cat, titles] of versionsSeenByCat.entries()) {
    if (titles.size > 1) {
      conflicts.push(
        `Multiple approved sources matched in "${cat}" (${Array.from(titles).join(', ')}). Verify the latest effective date.`,
      );
    }
  }

  return { chunks: top, conflicts };
}

export function buildIntelligenceContext(params: {
  query: string;
  model: AllowedModel;
  thinkingMode: ThinkingMode;
  communicationStyle: string;
  chunks: KnowledgeChunkRecord[];
  sources: KnowledgeSourceRecord[];
  memories: UserMemoryRecord[];
  feedback: FeedbackRecord[];
  learningRecords: LearningRecord[];
  prospect?: ProspectRecord | null;
  categoryFilter?: string;
}) {
  const retrieved = retrieveRelevantKnowledgeChunks(
    params.query,
    params.chunks,
    params.sources,
    params.categoryFilter ?? 'All',
  );

  const activeMemories = params.memories
    .filter((m) => m.status === 'active')
    .slice(0, 12)
    .map((m) => ({
      memoryType: m.memoryType,
      memoryContent: m.memoryContent,
      confidence: m.confidence,
    }));

  const positive = params.feedback.filter((f) => f.rating === 'positive').length;
  const negative = params.feedback.filter((f) => f.rating === 'negative').length;
  const issueCounts = new Map<string, number>();
  for (const f of params.feedback) {
    if (f.rating === 'negative') {
      issueCounts.set(f.feedbackType, (issueCounts.get(f.feedbackType) ?? 0) + 1);
    }
  }
  const topIssues = Array.from(issueCounts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4)
    .map(([k, v]) => `${k} (${v})`);

  const recentComments = params.feedback
    .filter((f) => f.comment.trim().length > 0)
    .slice(0, 5)
    .map((f) => `[${f.feedbackType}] ${f.comment}`);

  const activeStrategies = params.learningRecords
    .filter((r) => r.status === 'approved' && r.recordType !== 'knowledge_gap')
    .sort((a, b) => b.instructionVersion - a.instructionVersion)
    .slice(0, 8)
    .map((r) => ({
      version: r.instructionVersion,
      title: r.title,
      proposedChange: r.proposedChange || r.description,
    }));

  return {
    model: params.model,
    thinkingMode: params.thinkingMode,
    communicationStyle: params.communicationStyle,
    knowledgeChunks: retrieved.chunks.map(({ sourceTitle, category, documentVersion, sectionTitle, content }) => ({
      sourceTitle,
      category,
      documentVersion,
      sectionTitle,
      content,
    })),
    userMemories: activeMemories,
    feedbackSummary: {
      helpfulCount: positive,
      negativeCount: negative,
      topIssues,
      recentComments,
    },
    activeStrategies,
    prospectProfile: params.prospect
      ? {
          displayName: params.prospect.displayName,
          tradingExperience: params.prospect.tradingExperience,
          preferredChallenge: params.prospect.preferredChallenge,
          preferredAccountSize: params.prospect.preferredAccountSize,
          primaryConcern: params.prospect.primaryConcern,
          objections: params.prospect.objections,
          verifiedNotes: params.prospect.verifiedNotes,
        }
      : undefined,
    localConflicts: retrieved.conflicts,
  };
}
