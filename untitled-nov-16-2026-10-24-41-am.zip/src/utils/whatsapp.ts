export function extractBestResponseText(content: string): string {
  const match = content.match(
    /BEST RESPONSE:\s*([\s\S]*?)(?:\n\s*(?:WHY IT WORKS:|NEXT MOVE:)|$)/i,
  );
  return match ? match[1].trim() : content.trim();
}

/**
 * Extracts normalized E.164-like digits (without '+') if contactDetails contains a phone number.
 * Supports international numbers (+234..., +44..., +1...) and local Nigerian mobile numbers (070/080/081/090/091...).
 */
export function extractPhoneDigits(contactDetails?: string): string | null {
  if (!contactDetails) return null;

  const waMatch = contactDetails.match(/wa\.me\/(\d{7,15})/i);
  if (waMatch) return waMatch[1];

  // Strip everything except digits and leading +
  const raw = contactDetails.replace(/[^\d+]/g, '');
  if (!raw) return null;

  if (raw.startsWith('+')) {
    const digits = raw.slice(1).replace(/\D/g, '');
    return digits.length >= 7 && digits.length <= 15 ? digits : null;
  }

  const digits = raw.replace(/\D/g, '');
  // Convert 11-digit local Nigerian numbers (080..., 070..., 081..., 090..., 091...) to 234...
  if (/^0[789][01]\d{8}$/.test(digits)) {
    return `234${digits.slice(1)}`;
  }

  if (digits.length >= 10 && digits.length <= 15) {
    return digits;
  }

  return null;
}

export function buildWhatsAppUrl(messageText: string, contactDetails?: string): string {
  const encoded = encodeURIComponent(messageText.trim());
  const digits = extractPhoneDigits(contactDetails);
  if (digits) {
    return `https://wa.me/${digits}?text=${encoded}`;
  }
  return `https://wa.me/?text=${encoded}`;
}
