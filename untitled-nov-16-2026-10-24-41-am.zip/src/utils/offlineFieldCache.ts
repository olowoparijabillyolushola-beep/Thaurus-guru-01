import type {
  KnowledgeChunkRecord,
  KnowledgeSourceRecord,
  ProspectRecord,
  UserProfile,
} from '../types';

export interface OfflineFieldSnapshot {
  uid: string;
  workspaceId: string;
  profile: UserProfile | null;
  prospects: ProspectRecord[];
  knowledgeSources: KnowledgeSourceRecord[];
  knowledgeChunks: KnowledgeChunkRecord[];
  lastSyncedAt: string;
}

const CACHE_KEY_PREFIX = 'thaurus_guru_field_cache_v1_';
const LAST_UID_KEY = 'thaurus_guru_last_uid_v1';

export function saveLastActiveUid(uid: string): void {
  try {
    if (uid) {
      localStorage.setItem(LAST_UID_KEY, uid);
    }
  } catch {
    // Ignore storage quota / private mode errors
  }
}

export function loadLastActiveUid(): string | null {
  try {
    return localStorage.getItem(LAST_UID_KEY);
  } catch {
    return null;
  }
}

export function saveOfflineFieldCache(snapshot: OfflineFieldSnapshot): void {
  try {
    if (!snapshot.uid) return;
    saveLastActiveUid(snapshot.uid);
    localStorage.setItem(
      `${CACHE_KEY_PREFIX}${snapshot.uid}`,
      JSON.stringify({
        ...snapshot,
        // Keep up to 1500 chunks and 400 prospects to respect mobile localStorage limits
        prospects: snapshot.prospects.slice(0, 400),
        knowledgeSources: snapshot.knowledgeSources.slice(0, 200),
        knowledgeChunks: snapshot.knowledgeChunks.slice(0, 1500),
      }),
    );
  } catch {
    // Fallback gracefully if storage quota is tight
  }
}

export function loadOfflineFieldCache(uid: string): OfflineFieldSnapshot | null {
  try {
    const raw = localStorage.getItem(`${CACHE_KEY_PREFIX}${uid}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as OfflineFieldSnapshot;
    if (!parsed || parsed.uid !== uid) return null;
    return parsed;
  } catch {
    return null;
  }
}
