import { useCallback, useEffect, useRef, useState } from 'react';
import { apiUploadFile } from '../services/apiClient';

function pickSupportedAudioMime(): string {
  if (typeof MediaRecorder === 'undefined') return '';
  const candidates = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/mp4',
    'audio/ogg;codecs=opus',
    'audio/aac',
  ];
  for (const mime of candidates) {
    if (MediaRecorder.isTypeSupported(mime)) {
      return mime;
    }
  }
  return '';
}

export function useVoiceRecorder(options: {
  contextHint?: string;
  onTranscript: (text: string) => void;
  onError: (message: string) => void;
}) {
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [elapsedSec, setElapsedSec] = useState(0);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const optionsRef = useRef(options);
  optionsRef.current = options;

  const cleanupMedia = useCallback(() => {
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (streamRef.current) {
      for (const track of streamRef.current.getTracks()) {
        track.stop();
      }
      streamRef.current = null;
    }
    recorderRef.current = null;
  }, []);

  useEffect(() => {
    return () => {
      cleanupMedia();
    };
  }, [cleanupMedia]);

  const startRecording = useCallback(async () => {
    if (isRecording || isTranscribing) return;
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      optionsRef.current.onError('Microphone capture is not supported on this browser.');
      return;
    }
    if (typeof MediaRecorder === 'undefined') {
      optionsRef.current.onError('Audio recording is not supported on this browser.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      chunksRef.current = [];

      const preferredMime = pickSupportedAudioMime();
      const recorder = preferredMime
        ? new MediaRecorder(stream, { mimeType: preferredMime })
        : new MediaRecorder(stream);

      recorder.ondataavailable = (evt) => {
        if (evt.data && evt.data.size > 0) {
          chunksRef.current.push(evt.data);
        }
      };

      recorder.onstop = async () => {
        const mimeType = recorder.mimeType || preferredMime || 'audio/webm';
        const blob = new Blob(chunksRef.current, { type: mimeType });
        cleanupMedia();
        setIsRecording(false);

        if (blob.size < 250) {
          optionsRef.current.onError('Recording was too short. Please try speaking again.');
          return;
        }

        setIsTranscribing(true);
        try {
          const ext = mimeType.includes('mp4')
            ? 'm4a'
            : mimeType.includes('ogg')
              ? 'ogg'
              : 'webm';
          const fd = new FormData();
          fd.append('audio', blob, `voice-input.${ext}`);
          if (optionsRef.current.contextHint) {
            fd.append('contextHint', optionsRef.current.contextHint);
          }

          const res = await apiUploadFile<{ transcript: string }>('/api/ai/transcribe', fd);
          if (res.transcript?.trim()) {
            optionsRef.current.onTranscript(res.transcript.trim());
          } else {
            optionsRef.current.onError('No speech detected in recording.');
          }
        } catch (err) {
          optionsRef.current.onError(
            err instanceof Error ? err.message : 'Audio transcription failed.',
          );
        } finally {
          setIsTranscribing(false);
          setElapsedSec(0);
        }
      };

      recorderRef.current = recorder;
      recorder.start(250);
      setElapsedSec(0);
      setIsRecording(true);
      timerRef.current = window.setInterval(() => {
        setElapsedSec((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      cleanupMedia();
      setIsRecording(false);
      optionsRef.current.onError(
        err instanceof Error
          ? err.message
          : 'Microphone permission denied. Allow microphone access to use voice input.',
      );
    }
  }, [isRecording, isTranscribing, cleanupMedia]);

  const stopRecording = useCallback(() => {
    if (recorderRef.current && recorderRef.current.state !== 'inactive') {
      recorderRef.current.stop();
    }
  }, []);

  const toggleRecording = useCallback(() => {
    if (isRecording) {
      stopRecording();
    } else {
      void startRecording();
    }
  }, [isRecording, startRecording, stopRecording]);

  return {
    isRecording,
    isTranscribing,
    elapsedSec,
    toggleRecording,
    stopRecording,
  };
}
