import type { User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { OperationType, db, handleFirestoreError } from '../firebase';
import type {
  CommunicationChannel,
  CommunicationStyle,
  ConversationMessage,
  ConversationRecord,
  FeedbackRecord,
  FeedbackType,
  KnowledgeChunkRecord,
  KnowledgeSourceRecord,
  LearningRecord,
  ProspectRecord,
  SalesOutcomeRecord,
  SimulationCategoryScores,
  SimulationRecord,
  SimulationTranscriptTurn,
  ThinkingMode,
  UserMemoryRecord,
  UserProfile,
  WorkspaceRecord,
} from '../types';

export function makeId(prefix: string): string {
  const rand = crypto.randomUUID().replace(/-/g, '').slice(0, 14);
  return `${prefix}_${rand}`.replace(/[^a-zA-Z0-9_-]/g, '_');
}

function clampStr(val: string, max: number): string {
  return val.trim().slice(0, max);
}

export async function bootstrapUserAndWorkspace(firebaseUser: User): Promise<{
  profile: UserProfile;
  workspaceId: string;
}> {
  const uid = firebaseUser.uid;
  const userRef = doc(db, 'users', uid);
  const personalWsId = `ws_${uid}`.slice(0, 120);
  const wsRef = doc(db, 'workspaces', personalWsId);

  let profile: UserProfile | null = null;
  try {
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      profile = snap.data() as UserProfile;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${uid}`);
  }

  // Ensure personal workspace exists first (foreign key invariant)
  let wsExists = false;
  try {
    const wsSnap = await getDoc(wsRef);
    wsExists = wsSnap.exists();
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `workspaces/${personalWsId}`);
  }

  if (!wsExists) {
    try {
      const wsPayload = {
        workspaceId: personalWsId,
        workspaceName: 'Executive Sales Desk',
        companyName: 'Thaurus Guru',
        ownerUid: uid,
        visibility: 'private',
        configuration: {
          preferredModel: 'gemini-4-hydrogen',
          region: 'Nigeria & Global',
        },
        status: 'active',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      await setDoc(wsRef, wsPayload);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `workspaces/${personalWsId}`);
    }
  }

  if (!profile) {
    const isBootstrapOwner = firebaseUser.email === 'echelontix@gmail.com' && firebaseUser.emailVerified;
    const newProfile = {
      uid,
      displayName: clampStr(firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Executive', 120),
      email: clampStr(firebaseUser.email || 'user@thaurusguru.com', 200),
      role: isBootstrapOwner ? 'owner' : 'sales_executive',
      preferences: { theme: 'dark', preferredModel: 'gemini-4-hydrogen' },
      communicationStyle: 'Natural' as CommunicationStyle,
      defaultThinkingMode: 'auto' as ThinkingMode,
      activeWorkspaceId: personalWsId,
      accountStatus: 'active' as const,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    try {
      await setDoc(userRef, newProfile);
      const created = await getDoc(userRef);
      profile = created.data() as UserProfile;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${uid}`);
    }
  }

  return { profile: profile!, workspaceId: profile!.activeWorkspaceId || personalWsId };
}

export async function updateUserProfile(
  uid: string,
  updates: Partial<
    Pick<
      UserProfile,
      'displayName' | 'communicationStyle' | 'defaultThinkingMode' | 'activeWorkspaceId' | 'preferences'
    >
  >,
): Promise<void> {
  const path = `users/${uid}`;
  try {
    await updateDoc(doc(db, 'users', uid), {
      ...updates,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function grantAdminRole(targetUid: string, targetEmail: string, grantedBy: string): Promise<void> {
  const path = `admins/${targetUid}`;
  try {
    await setDoc(doc(db, 'admins', targetUid), {
      uid: clampStr(targetUid, 128),
      email: clampStr(targetEmail, 200),
      grantedBy: clampStr(grantedBy, 128),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

// ── Conversations & Messages ───────────────────────────────────────────
export async function createConversation(params: {
  userId: string;
  workspaceId: string;
  title: string;
  channel: CommunicationChannel;
  mode: ThinkingMode;
  module: ConversationRecord['module'];
  prospectId?: string;
}): Promise<string> {
  const conversationId = makeId('conv');
  const path = `conversations/${conversationId}`;
  try {
    await setDoc(doc(db, 'conversations', conversationId), {
      conversationId,
      userId: params.userId,
      workspaceId: params.workspaceId,
      prospectId: params.prospectId ? clampStr(params.prospectId, 128) : '',
      title: clampStr(params.title || 'Live Sales Session', 200),
      channel: params.channel,
      mode: params.mode,
      module: params.module,
      status: 'active',
      outcome: '',
      analysed: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return conversationId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateConversationStatus(
  conversationId: string,
  updates: Partial<Pick<ConversationRecord, 'status' | 'outcome' | 'analysed'>>,
): Promise<void> {
  const path = `conversations/${conversationId}`;
  try {
    await updateDoc(doc(db, 'conversations', conversationId), {
      ...updates,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function linkConversationProspect(
  conversationId: string,
  prospectId: string,
): Promise<void> {
  const path = `conversations/${conversationId}`;
  try {
    await updateDoc(doc(db, 'conversations', conversationId), {
      prospectId: clampStr(prospectId, 128),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteConversation(conversationId: string): Promise<void> {
  const path = `conversations/${conversationId}`;
  try {
    await deleteDoc(doc(db, 'conversations', conversationId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function addConversationMessage(params: {
  conversationId: string;
  userId: string;
  role: 'user' | 'assistant' | 'prospect';
  content: string;
  mode: ThinkingMode;
  sourceReferences?: string[];
  tokenUsage?: number;
  responseLatency?: number;
}): Promise<string> {
  const messageId = makeId('msg');
  const path = `conversations/${params.conversationId}/messages/${messageId}`;
  try {
    await setDoc(doc(db, 'conversations', params.conversationId, 'messages', messageId), {
      messageId,
      userId: params.userId,
      role: params.role,
      content: clampStr(params.content, 24000),
      mode: params.mode,
      sourceReferences: (params.sourceReferences ?? []).slice(0, 20).map((s) => clampStr(s, 200)),
      feedbackStatus: 'none',
      tokenUsage: Math.max(0, Math.round(params.tokenUsage ?? 0)),
      responseLatency: Math.max(0, Math.round(params.responseLatency ?? 0)),
      timestamp: serverTimestamp(),
    });
    return messageId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function setMessageFeedbackStatus(
  conversationId: string,
  messageId: string,
  feedbackStatus: string,
): Promise<void> {
  const path = `conversations/${conversationId}/messages/${messageId}`;
  try {
    await updateDoc(doc(db, 'conversations', conversationId, 'messages', messageId), {
      feedbackStatus: clampStr(feedbackStatus, 80),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// ── Prospects ──────────────────────────────────────────────────────────
export async function saveProspect(params: {
  prospectId?: string;
  userId: string;
  workspaceId: string;
  displayName: string;
  contactDetails?: string;
  tradingExperience: string;
  previousPropFirm?: string;
  preferredAccountSize: string;
  preferredChallenge: string;
  primaryConcern: string;
  objections: string[];
  buyingSignals: string[];
  verifiedNotes: string;
  aiObservations: string;
  followUpDate?: string;
  status: ProspectRecord['status'];
  outcome?: string;
}): Promise<string> {
  const isNew = !params.prospectId;
  const prospectId = params.prospectId || makeId('pros');
  const path = `prospects/${prospectId}`;

  const cleanObjections = params.objections.slice(0, 25).map((s) => clampStr(s, 200)).filter(Boolean);
  const cleanSignals = params.buyingSignals.slice(0, 25).map((s) => clampStr(s, 200)).filter(Boolean);

  try {
    if (isNew) {
      await setDoc(doc(db, 'prospects', prospectId), {
        prospectId,
        userId: params.userId,
        workspaceId: params.workspaceId,
        displayName: clampStr(params.displayName, 140),
        contactDetails: clampStr(params.contactDetails ?? '', 200),
        tradingExperience: clampStr(params.tradingExperience, 200),
        previousPropFirm: clampStr(params.previousPropFirm ?? '', 200),
        preferredAccountSize: clampStr(params.preferredAccountSize, 100),
        preferredChallenge: clampStr(params.preferredChallenge, 140),
        primaryConcern: clampStr(params.primaryConcern, 500),
        objections: cleanObjections,
        buyingSignals: cleanSignals,
        verifiedNotes: clampStr(params.verifiedNotes, 4000),
        aiObservations: clampStr(params.aiObservations, 4000),
        followUpDate: clampStr(params.followUpDate ?? '', 40),
        status: params.status,
        outcome: clampStr(params.outcome ?? '', 300),
        lastInteraction: serverTimestamp(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      // Split into verified profile update vs AI/status update to match Action-Based Update rules
      await updateDoc(doc(db, 'prospects', prospectId), {
        displayName: clampStr(params.displayName, 140),
        contactDetails: clampStr(params.contactDetails ?? '', 200),
        tradingExperience: clampStr(params.tradingExperience, 200),
        previousPropFirm: clampStr(params.previousPropFirm ?? '', 200),
        preferredAccountSize: clampStr(params.preferredAccountSize, 100),
        preferredChallenge: clampStr(params.preferredChallenge, 140),
        primaryConcern: clampStr(params.primaryConcern, 500),
        objections: cleanObjections,
        buyingSignals: cleanSignals,
        verifiedNotes: clampStr(params.verifiedNotes, 4000),
        followUpDate: clampStr(params.followUpDate ?? '', 40),
        updatedAt: serverTimestamp(),
      });
      await updateDoc(doc(db, 'prospects', prospectId), {
        aiObservations: clampStr(params.aiObservations, 4000),
        lastInteraction: serverTimestamp(),
        status: params.status,
        outcome: clampStr(params.outcome ?? '', 300),
        updatedAt: serverTimestamp(),
      });
    }
    return prospectId;
  } catch (error) {
    handleFirestoreError(error, isNew ? OperationType.CREATE : OperationType.UPDATE, path);
  }
}

export async function deleteProspect(prospectId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'prospects', prospectId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `prospects/${prospectId}`);
  }
}

export async function updateProspectFollowUp(
  prospectId: string,
  updates: { followUpDate?: string; status?: ProspectRecord['status'] },
): Promise<void> {
  const path = `prospects/${prospectId}`;
  try {
    if (updates.followUpDate !== undefined) {
      await updateDoc(doc(db, 'prospects', prospectId), {
        followUpDate: clampStr(updates.followUpDate, 40),
        updatedAt: serverTimestamp(),
      });
    }
    if (updates.status !== undefined) {
      await updateDoc(doc(db, 'prospects', prospectId), {
        status: updates.status,
        lastInteraction: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// ── Knowledge Base (Sources + Chunks) ──────────────────────────────────
export async function saveKnowledgeSourceWithChunks(params: {
  workspaceId: string;
  uploadedBy: string;
  isAdmin: boolean;
  title: string;
  sourceType: KnowledgeSourceRecord['sourceType'];
  originalFileName?: string;
  sourceUrl?: string;
  category: string;
  documentVersion: number;
  effectiveDate: string;
  contentHash: string;
  chunks: Array<{
    content: string;
    keywords: string[];
    pageNumber: number;
    sectionTitle: string;
  }>;
}): Promise<string> {
  const sourceId = makeId('ksrc');
  const approvalStatus = params.isAdmin ? 'approved' : 'pending';
  const sourcePath = `knowledgeSources/${sourceId}`;

  try {
    await setDoc(doc(db, 'knowledgeSources', sourceId), {
      sourceId,
      workspaceId: params.workspaceId,
      title: clampStr(params.title, 220),
      sourceType: params.sourceType,
      originalFileName: clampStr(params.originalFileName ?? '', 240),
      storagePath: '',
      sourceUrl: clampStr(params.sourceUrl ?? '', 500),
      category: clampStr(params.category, 100),
      documentVersion: Math.max(1, params.documentVersion),
      uploadedBy: params.uploadedBy,
      uploadedAt: serverTimestamp(),
      effectiveDate: clampStr(params.effectiveDate, 40),
      approvalStatus,
      approvedBy: params.isAdmin ? params.uploadedBy : '',
      approvedAt: params.isAdmin ? new Date().toISOString().slice(0, 10) : '',
      contentHash: clampStr(params.contentHash, 128),
    });

    // Write chunks in batches of 400
    for (let i = 0; i < params.chunks.length; i += 400) {
      const batch = writeBatch(db);
      const slice = params.chunks.slice(i, i + 400);
      for (const ch of slice) {
        const chunkId = makeId('kchk');
        batch.set(doc(db, 'knowledgeChunks', chunkId), {
          chunkId,
          sourceId,
          workspaceId: params.workspaceId,
          uploadedBy: params.uploadedBy,
          content: clampStr(ch.content, 6000),
          category: clampStr(params.category, 100),
          keywords: ch.keywords.slice(0, 40).map((k) => clampStr(k, 80)),
          pageNumber: Math.max(1, ch.pageNumber),
          sectionTitle: clampStr(ch.sectionTitle, 200),
          documentVersion: Math.max(1, params.documentVersion),
          approvalStatus,
          createdAt: serverTimestamp(),
        });
      }
      await batch.commit();
    }
    return sourceId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, sourcePath);
  }
}

export async function updateKnowledgeApproval(params: {
  sourceId: string;
  chunks: KnowledgeChunkRecord[];
  status: KnowledgeSourceRecord['approvalStatus'];
  adminUid: string;
}): Promise<void> {
  const path = `knowledgeSources/${params.sourceId}`;
  try {
    await updateDoc(doc(db, 'knowledgeSources', params.sourceId), {
      approvalStatus: params.status,
      approvedBy: params.adminUid,
      approvedAt: new Date().toISOString().slice(0, 10),
    });

    const related = params.chunks.filter((c) => c.sourceId === params.sourceId);
    for (let i = 0; i < related.length; i += 400) {
      const batch = writeBatch(db);
      for (const ch of related.slice(i, i + 400)) {
        batch.update(doc(db, 'knowledgeChunks', ch.chunkId), {
          approvalStatus: params.status,
        });
      }
      await batch.commit();
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteKnowledgeSource(
  sourceId: string,
  chunks: KnowledgeChunkRecord[],
): Promise<void> {
  try {
    const related = chunks.filter((c) => c.sourceId === sourceId);
    for (let i = 0; i < related.length; i += 400) {
      const batch = writeBatch(db);
      for (const ch of related.slice(i, i + 400)) {
        batch.delete(doc(db, 'knowledgeChunks', ch.chunkId));
      }
      await batch.commit();
    }
    await deleteDoc(doc(db, 'knowledgeSources', sourceId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `knowledgeSources/${sourceId}`);
  }
}

// ── Layer 1: User Memory ───────────────────────────────────────────────
export async function saveUserMemory(params: {
  memoryId?: string;
  userId: string;
  workspaceId: string;
  memoryType: UserMemoryRecord['memoryType'];
  memoryContent: string;
  confidence: UserMemoryRecord['confidence'];
  sourceConversationId?: string;
  status?: 'active' | 'archived';
}): Promise<string> {
  const isNew = !params.memoryId;
  const memoryId = params.memoryId || makeId('mem');
  const path = `userMemory/${memoryId}`;
  try {
    if (isNew) {
      await setDoc(doc(db, 'userMemory', memoryId), {
        memoryId,
        userId: params.userId,
        workspaceId: params.workspaceId,
        memoryType: params.memoryType,
        memoryContent: clampStr(params.memoryContent, 2000),
        confidence: params.confidence,
        sourceConversationId: clampStr(params.sourceConversationId ?? '', 128),
        createdAt: serverTimestamp(),
        lastUsedAt: serverTimestamp(),
        status: params.status ?? 'active',
      });
    } else {
      await updateDoc(doc(db, 'userMemory', memoryId), {
        memoryType: params.memoryType,
        memoryContent: clampStr(params.memoryContent, 2000),
        confidence: params.confidence,
        status: params.status ?? 'active',
        lastUsedAt: serverTimestamp(),
      });
    }
    return memoryId;
  } catch (error) {
    handleFirestoreError(error, isNew ? OperationType.CREATE : OperationType.UPDATE, path);
  }
}

export async function deleteUserMemory(memoryId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'userMemory', memoryId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `userMemory/${memoryId}`);
  }
}

// ── Layer 2: Feedback ──────────────────────────────────────────────────
export async function recordFeedback(params: {
  userId: string;
  conversationId: string;
  messageId: string;
  rating: 'positive' | 'negative';
  feedbackType: FeedbackType;
  comment: string;
}): Promise<string> {
  const feedbackId = makeId('fb');
  const path = `feedback/${feedbackId}`;
  try {
    await setDoc(doc(db, 'feedback', feedbackId), {
      feedbackId,
      userId: params.userId,
      conversationId: params.conversationId,
      messageId: params.messageId,
      rating: params.rating,
      feedbackType: params.feedbackType,
      comment: clampStr(params.comment, 1500),
      createdAt: serverTimestamp(),
    });
    await setMessageFeedbackStatus(params.conversationId, params.messageId, params.feedbackType);
    return feedbackId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

// ── Layer 3: Sales Outcomes ────────────────────────────────────────────
export async function recordSalesOutcome(params: {
  userId: string;
  prospectId?: string;
  conversationId?: string;
  outcomeType: SalesOutcomeRecord['outcomeType'];
  product: string;
  salesValue: number;
  currency: string;
  strategyUsed: string;
  blockingObjection?: string;
  outcomeNotes: string;
}): Promise<string> {
  const outcomeId = makeId('out');
  const path = `salesOutcomes/${outcomeId}`;
  try {
    await setDoc(doc(db, 'salesOutcomes', outcomeId), {
      outcomeId,
      userId: params.userId,
      prospectId: clampStr(params.prospectId ?? '', 128),
      conversationId: clampStr(params.conversationId ?? '', 128),
      outcomeType: params.outcomeType,
      product: clampStr(params.product, 140),
      salesValue: Math.max(0, Number(params.salesValue) || 0),
      currency: clampStr(params.currency || 'USD', 12),
      strategyUsed: clampStr(params.strategyUsed, 200),
      blockingObjection: clampStr(params.blockingObjection ?? '', 240),
      outcomeNotes: clampStr(params.outcomeNotes, 2000),
      recordedAt: serverTimestamp(),
    });
    return outcomeId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

// ── Simulations ────────────────────────────────────────────────────────
export async function createSimulation(params: {
  userId: string;
  prospectType: string;
  difficulty: SimulationRecord['difficulty'];
  initialTranscript: SimulationTranscriptTurn[];
}): Promise<string> {
  const simulationId = makeId('sim');
  const path = `simulations/${simulationId}`;
  try {
    await setDoc(doc(db, 'simulations', simulationId), {
      simulationId,
      userId: params.userId,
      prospectType: clampStr(params.prospectType, 100),
      difficulty: params.difficulty,
      transcript: params.initialTranscript,
      categoryScores: {},
      overallScore: 0,
      feedback: '',
      improvementTarget: '',
      status: 'in_progress',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return simulationId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function appendSimulationTranscript(
  simulationId: string,
  transcript: SimulationTranscriptTurn[],
): Promise<void> {
  try {
    await updateDoc(doc(db, 'simulations', simulationId), {
      transcript: transcript.slice(0, 120),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `simulations/${simulationId}`);
  }
}

export async function finalizeSimulationScore(params: {
  simulationId: string;
  transcript: SimulationTranscriptTurn[];
  categoryScores: SimulationCategoryScores;
  overallScore: number;
  feedback: string;
  improvementTarget: string;
}): Promise<void> {
  try {
    await updateDoc(doc(db, 'simulations', params.simulationId), {
      transcript: params.transcript.slice(0, 120),
      categoryScores: params.categoryScores,
      overallScore: Math.min(10, Math.max(0, Number(params.overallScore) || 0)),
      feedback: clampStr(params.feedback, 4000),
      improvementTarget: clampStr(params.improvementTarget, 500),
      status: 'completed',
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `simulations/${params.simulationId}`);
  }
}

// ── Layer 4 & 5: Learning Records ──────────────────────────────────────
export async function createLearningRecord(params: {
  workspaceId: string;
  recordType: LearningRecord['recordType'];
  title: string;
  description: string;
  evidenceSummary?: string;
  proposedChange?: string;
  instructionVersion: number;
  createdBy: string;
  isAdmin: boolean;
  autoApprove?: boolean;
  reason?: string;
}): Promise<string> {
  const learningId = makeId('lrn');
  const path = `learningRecords/${learningId}`;
  const approve = params.isAdmin && params.autoApprove;
  try {
    await setDoc(doc(db, 'learningRecords', learningId), {
      learningId,
      workspaceId: params.workspaceId,
      recordType: params.recordType,
      title: clampStr(params.title, 200),
      description: clampStr(params.description, 2500),
      evidenceSummary: clampStr(params.evidenceSummary ?? '', 2000),
      proposedChange: clampStr(params.proposedChange ?? '', 3000),
      instructionVersion: Math.max(1, params.instructionVersion),
      status: approve ? 'approved' : 'pending_review',
      createdBy: params.createdBy,
      reviewedBy: approve ? params.createdBy : '',
      reason: clampStr(params.reason ?? '', 1000),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return learningId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function reviewLearningRecord(params: {
  learningId: string;
  status: LearningRecord['status'];
  reviewedBy: string;
  reason: string;
  instructionVersion?: number;
}): Promise<void> {
  const path = `learningRecords/${params.learningId}`;
  try {
    const payload: Record<string, unknown> = {
      status: params.status,
      reviewedBy: clampStr(params.reviewedBy, 128),
      reason: clampStr(params.reason, 1000),
      updatedAt: serverTimestamp(),
    };
    if (params.instructionVersion !== undefined) {
      payload.instructionVersion = Math.max(1, params.instructionVersion);
    }
    await updateDoc(doc(db, 'learningRecords', params.learningId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

function tsMillis(ts: { toMillis?: () => number } | undefined): number {
  return ts && typeof ts.toMillis === 'function' ? ts.toMillis() : 0;
}

// ── Real-time Subscriptions ────────────────────────────────────────────
export function subscribeUserCollections(
  uid: string,
  callbacks: {
    onConversations: (items: ConversationRecord[]) => void;
    onProspects: (items: ProspectRecord[]) => void;
    onMemories: (items: UserMemoryRecord[]) => void;
    onFeedback: (items: FeedbackRecord[]) => void;
    onOutcomes: (items: SalesOutcomeRecord[]) => void;
    onSimulations: (items: SimulationRecord[]) => void;
    onKnowledgeSources: (items: KnowledgeSourceRecord[]) => void;
    onKnowledgeChunks: (items: KnowledgeChunkRecord[]) => void;
    onLearningRecords: (items: LearningRecord[]) => void;
    onWorkspaces: (items: WorkspaceRecord[]) => void;
  },
): () => void {
  const unsubs: Array<() => void> = [];

  unsubs.push(
    onSnapshot(
      query(collection(db, 'conversations'), where('userId', '==', uid)),
      (snap) => {
        const items = snap.docs.map((d) => d.data() as ConversationRecord);
        items.sort((a, b) => tsMillis(b.updatedAt) - tsMillis(a.updatedAt));
        callbacks.onConversations(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'conversations'),
    ),
  );

  unsubs.push(
    onSnapshot(
      query(collection(db, 'prospects'), where('userId', '==', uid)),
      (snap) => {
        const items = snap.docs.map((d) => d.data() as ProspectRecord);
        items.sort((a, b) => tsMillis(b.updatedAt) - tsMillis(a.updatedAt));
        callbacks.onProspects(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'prospects'),
    ),
  );

  unsubs.push(
    onSnapshot(
      query(collection(db, 'userMemory'), where('userId', '==', uid)),
      (snap) => {
        const items = snap.docs.map((d) => d.data() as UserMemoryRecord);
        items.sort((a, b) => tsMillis(b.lastUsedAt) - tsMillis(a.lastUsedAt));
        callbacks.onMemories(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'userMemory'),
    ),
  );

  unsubs.push(
    onSnapshot(
      query(collection(db, 'feedback'), where('userId', '==', uid)),
      (snap) => {
        const items = snap.docs.map((d) => d.data() as FeedbackRecord);
        items.sort((a, b) => tsMillis(b.createdAt) - tsMillis(a.createdAt));
        callbacks.onFeedback(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'feedback'),
    ),
  );

  unsubs.push(
    onSnapshot(
      query(collection(db, 'salesOutcomes'), where('userId', '==', uid)),
      (snap) => {
        const items = snap.docs.map((d) => d.data() as SalesOutcomeRecord);
        items.sort((a, b) => tsMillis(b.recordedAt) - tsMillis(a.recordedAt));
        callbacks.onOutcomes(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'salesOutcomes'),
    ),
  );

  unsubs.push(
    onSnapshot(
      query(collection(db, 'simulations'), where('userId', '==', uid)),
      (snap) => {
        const items = snap.docs.map((d) => d.data() as SimulationRecord);
        items.sort((a, b) => tsMillis(b.createdAt) - tsMillis(a.createdAt));
        callbacks.onSimulations(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'simulations'),
    ),
  );

  // Knowledge sources/chunks: query approved OR own pending
  let approvedSources: KnowledgeSourceRecord[] = [];
  let ownSources: KnowledgeSourceRecord[] = [];
  const emitSources = () => {
    const merged = new Map<string, KnowledgeSourceRecord>();
    for (const s of [...approvedSources, ...ownSources]) merged.set(s.sourceId, s);
    const arr = Array.from(merged.values());
    arr.sort((a, b) => tsMillis(b.uploadedAt) - tsMillis(a.uploadedAt));
    callbacks.onKnowledgeSources(arr);
  };

  unsubs.push(
    onSnapshot(
      query(collection(db, 'knowledgeSources'), where('approvalStatus', '==', 'approved')),
      (snap) => {
        approvedSources = snap.docs.map((d) => d.data() as KnowledgeSourceRecord);
        emitSources();
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'knowledgeSources'),
    ),
  );
  unsubs.push(
    onSnapshot(
      query(collection(db, 'knowledgeSources'), where('uploadedBy', '==', uid)),
      (snap) => {
        ownSources = snap.docs.map((d) => d.data() as KnowledgeSourceRecord);
        emitSources();
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'knowledgeSources'),
    ),
  );

  let approvedChunks: KnowledgeChunkRecord[] = [];
  let ownChunks: KnowledgeChunkRecord[] = [];
  const emitChunks = () => {
    const merged = new Map<string, KnowledgeChunkRecord>();
    for (const c of [...approvedChunks, ...ownChunks]) merged.set(c.chunkId, c);
    callbacks.onKnowledgeChunks(Array.from(merged.values()));
  };

  unsubs.push(
    onSnapshot(
      query(collection(db, 'knowledgeChunks'), where('approvalStatus', '==', 'approved')),
      (snap) => {
        approvedChunks = snap.docs.map((d) => d.data() as KnowledgeChunkRecord);
        emitChunks();
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'knowledgeChunks'),
    ),
  );
  unsubs.push(
    onSnapshot(
      query(collection(db, 'knowledgeChunks'), where('uploadedBy', '==', uid)),
      (snap) => {
        ownChunks = snap.docs.map((d) => d.data() as KnowledgeChunkRecord);
        emitChunks();
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'knowledgeChunks'),
    ),
  );

  let approvedLearning: LearningRecord[] = [];
  let ownLearning: LearningRecord[] = [];
  const emitLearning = () => {
    const merged = new Map<string, LearningRecord>();
    for (const l of [...approvedLearning, ...ownLearning]) merged.set(l.learningId, l);
    const arr = Array.from(merged.values());
    arr.sort((a, b) => tsMillis(b.createdAt) - tsMillis(a.createdAt));
    callbacks.onLearningRecords(arr);
  };

  unsubs.push(
    onSnapshot(
      query(collection(db, 'learningRecords'), where('status', '==', 'approved')),
      (snap) => {
        approvedLearning = snap.docs.map((d) => d.data() as LearningRecord);
        emitLearning();
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'learningRecords'),
    ),
  );
  unsubs.push(
    onSnapshot(
      query(collection(db, 'learningRecords'), where('createdBy', '==', uid)),
      (snap) => {
        ownLearning = snap.docs.map((d) => d.data() as LearningRecord);
        emitLearning();
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'learningRecords'),
    ),
  );

  unsubs.push(
    onSnapshot(
      query(collection(db, 'workspaces'), where('ownerUid', '==', uid)),
      (snap) => callbacks.onWorkspaces(snap.docs.map((d) => d.data() as WorkspaceRecord)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'workspaces'),
    ),
  );

  return () => {
    for (const unsub of unsubs) unsub();
  };
}

export function subscribeConversationMessages(
  conversationId: string,
  uid: string,
  onMessages: (msgs: ConversationMessage[]) => void,
): () => void {
  const q = query(
    collection(db, 'conversations', conversationId, 'messages'),
    where('userId', '==', uid),
  );
  return onSnapshot(
    q,
    (snap) => {
      const msgs = snap.docs.map((d) => d.data() as ConversationMessage);
      msgs.sort((a, b) => tsMillis(a.timestamp) - tsMillis(b.timestamp));
      onMessages(msgs);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, `conversations/${conversationId}/messages`),
  );
}
