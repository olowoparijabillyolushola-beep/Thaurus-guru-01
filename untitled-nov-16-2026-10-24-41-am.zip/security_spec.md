# Security Specification — Thaurus Guru Sales Intelligence OS

## 1. Data Invariants
1. **Default Deny**: All unspecified paths under `/databases/{database}/documents` are denied by the top-level catch-all rule.
2. **Email Verification**: Every authenticated read/write requires `request.auth != null && request.auth.token.email_verified == true`.
3. **PII Isolation**: `/users/{userId}` contains `email` and `displayName`; read/write is strictly restricted to `isOwner(userId)` or `isAdmin()`. No blanket `isSignedIn()` reads or list queries are allowed on `users`.
4. **Anti-Self-Promotion**: On `/users/{userId}` creation, non-admin users MUST only register with `role == 'sales_executive'` and `accountStatus == 'active'`, and cannot change `role` or `accountStatus` on update.
5. **Owner Scoping & Query Enforcement**: Every `conversations`, `prospects`, `userMemory`, `feedback`, `salesOutcomes`, and `simulations` document enforces `userId == request.auth.uid` on create, `userId == existing().userId` immutability on update, and `resource.data.userId == request.auth.uid` on `allow list` (zero `get()`/`exists()` inside `allow list`).
6. **Subcollection Master Gate**: `/conversations/{conversationId}/messages/{messageId}` verifies both `userId == request.auth.uid` on the message and parent conversation ownership via `get()` on single-document operations (`get`, `create`, `update`, `delete`), while enforcing `resource.data.userId == request.auth.uid` on `list`.
7. **Verified Knowledge & Strategy Governance**: Non-admin executives may only read `knowledgeSources` and `knowledgeChunks` where `approvalStatus == 'approved'` (or their own pending uploads), and may submit `learningRecords` only with `status == 'pending_review'`. Only administrators may approve, supersede, reject, or roll back `knowledgeSources`, `knowledgeChunks`, or `learningRecords`.
8. **Temporal Integrity & Path Hardening**: All document IDs are validated with `^[a-zA-Z0-9_\-]+$` (`size <= 128`), all string fields enforce explicit `.size()` bounds, and `createdAt`/`updatedAt`/`timestamp`/`recordedAt`/`uploadedAt` must equal `request.time`.

## 2. Dirty Dozen Adversarial Payloads (Must Return PERMISSION_DENIED)
1. **Ghost Field Injection (`users`)**: User creates `/users/u1` with `{ ..., isSuperAdmin: true }` -> Blocked by `keys().hasOnly(...)`.
2. **Self-Role Escalation (`users`)**: Sales executive creates `/users/u1` with `role: 'administrator'` -> Blocked by `role == 'sales_executive'` guard.
3. **Update Role Escalation (`users`)**: Sales executive updates `/users/u1` changing `role` to `'owner'` -> Blocked by `affectedKeys().hasOnly(...)` + immutable `role`.
4. **Cross-Tenant PII Read (`users`)**: User A requests `get(/users/userB)` -> Blocked by `isOwner(userId) || isAdmin()`.
5. **Blanket List Query (`prospects`)**: User A lists `/prospects` without `where('userId', '==', uid)` -> Blocked by `allow list: if resource.data.userId == request.auth.uid`.
6. **ID Poisoning (`conversations`)**: User creates `/conversations/../../evil_1500_chars...` -> Blocked by `isValidId(conversationId)`.
7. **Orphan Message Write (`messages`)**: User B tries to write `/conversations/convBelongingToA/messages/m1` -> Blocked by Master Gate `get()` on parent conversation.
8. **Client Timestamp Forgery (`salesOutcomes`)**: User sends `recordedAt: "2020-01-01T00:00:00Z"` instead of `request.time` -> Blocked by `incoming().recordedAt == request.time`.
9. **Unapproved Knowledge Poisoning (`knowledgeSources`)**: Non-admin creates a `knowledgeSource` directly with `approvalStatus: 'approved'` -> Blocked by approval status gate (`approvalStatus == 'pending'` for non-admins).
10. **Instruction Tampering (`learningRecords`)**: Non-admin updates a `learningRecord` to `status: 'approved'` -> Blocked by admin-only review gate.
11. **Terminal State Bypass (`simulations`)**: User attempts to overwrite a `completed` simulation's `overallScore` -> Blocked by terminal state lock (`existing().status != 'completed'`).
12. **Unbounded Payload / Resource Exhaustion (`userMemory`)**: User submits a 100KB string in `memoryContent` -> Blocked by `memoryContent.size() <= 2000`.
