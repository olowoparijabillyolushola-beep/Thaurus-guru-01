import 'dotenv/config';
import path from 'node:path';
import express from 'express';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import {
  ApiError,
  type AuthenticatedRequest,
  errorHandler,
  requireAuth,
} from './server/authMiddleware.ts';
import { importFromUrl, parseUploadedDocument } from './server/documentParser.ts';
import {
  CLOSING_SCHEMA,
  COLD_CALL_SCHEMA,
  type IntelligenceContextPayload,
  OBJECTION_SCHEMA,
  PRODUCT_QA_SCHEMA,
  PROSPECT_ANALYSIS_SCHEMA,
  PROSPECT_EXTRACTION_SCHEMA,
  SIMULATION_SCORE_SCHEMA,
  STRATEGY_PROPOSAL_SCHEMA,
  generateSimulationTurn,
  generateStructuredJson,
  streamLiveAssistant,
  transcribeAudio,
} from './server/gemini.ts';

const PORT = Number(process.env.PORT ?? 3000);
const app = express();

app.use(express.json({ limit: '15mb' }));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
});

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'thaurus-guru-sales-intelligence-os' });
});

// ── Live Sales Assistant (SSE Streaming) ───────────────────────────────
app.post('/api/ai/live-assist/stream', requireAuth, async (req: AuthenticatedRequest, res, next) => {
  try {
    const {
      prompt,
      channel = 'WhatsApp',
      style = 'Natural',
      responseOnly = false,
      history = [],
      imageAttachment,
      context = {},
    } = req.body as {
      prompt?: string;
      channel?: string;
      style?: string;
      responseOnly?: boolean;
      history?: Array<{ role: 'user' | 'assistant'; content: string }>;
      imageAttachment?: { mimeType: string; dataBase64: string };
      context?: IntelligenceContextPayload;
    };

    if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
      throw new ApiError(400, 'INVALID_INPUT', 'Prompt text is required.');
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const result = await streamLiveAssistant({
      prompt: prompt.trim(),
      channel,
      style,
      responseOnly: Boolean(responseOnly),
      history: Array.isArray(history) ? history : [],
      imageAttachment,
      context,
      onChunk: (text) => {
        res.write(`data: ${JSON.stringify({ type: 'chunk', text })}\n\n`);
      },
    });

    res.write(
      `data: ${JSON.stringify({
        type: 'done',
        resolvedMode: result.resolvedMode,
        tokenUsage: result.tokenUsage,
        latencyMs: result.latencyMs,
      })}\n\n`,
    );
    res.end();
  } catch (err) {
    if (res.headersSent) {
      const msg = err instanceof Error ? err.message : 'Streaming failed.';
      res.write(`data: ${JSON.stringify({ type: 'error', error: msg })}\n\n`);
      res.end();
      return;
    }
    next(err);
  }
});

// ── Objection Intelligence ─────────────────────────────────────────────
app.post('/api/ai/objection', requireAuth, async (req: AuthenticatedRequest, res, next) => {
  try {
    const { objection, channel = 'WhatsApp', style = 'Confident', extraContext = '', context = {} } =
      req.body as {
        objection?: string;
        channel?: string;
        style?: string;
        extraContext?: string;
        context?: IntelligenceContextPayload;
      };

    if (!objection?.trim()) {
      throw new ApiError(400, 'INVALID_INPUT', 'Objection text is required.');
    }

    const result = await generateStructuredJson({
      prompt: `Channel: ${channel}\nPreferred Tone: ${style}\nProspect Objection: "${objection.trim()}"\nAdditional Context: ${extraContext || 'None'}`,
      taskDirective: `Analyse this prop-trading sales objection thoroughly.
Identify:
1. surfaceObjection
2. underlyingConcern
3. prospectMotivation
4. recommendedResponse (aligned with tone "${style}" and channel "${channel}", never inventing facts)
5. supportingEvidence (only claims supported by Verified Knowledge Chunks; if none, state clearly)
6. followUpQuestion (one sharp discovery/clarifying question)
7. suggestedNextStep
8. alternativeResponses (3 variations: Confident, Empathetic, Direct)
9. missingKnowledgeGap (empty string if all claims are covered by Verified Knowledge Chunks, otherwise describe the exact missing verified policy/fact needed).`,
      schema: OBJECTION_SCHEMA,
      context,
      forceDeep: true,
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

// ── Closing Intelligence ───────────────────────────────────────────────
app.post('/api/ai/closing', requireAuth, async (req: AuthenticatedRequest, res, next) => {
  try {
    const { conversationText, goal = '', context = {} } = req.body as {
      conversationText?: string;
      goal?: string;
      context?: IntelligenceContextPayload;
    };

    if (!conversationText?.trim()) {
      throw new ApiError(400, 'INVALID_INPUT', 'Conversation text is required for closing analysis.');
    }

    const result = await generateStructuredJson({
      prompt: `Sales Goal: ${goal || 'Convert prospect into an appropriate Thaurus Guru challenge evaluation'}\n\nConversation:\n${conversationText.trim()}`,
      taskDirective: `Evaluate closing readiness honestly.
Score readinessScore (0-100), set readinessLabel (Early / Warming / Ready / Stalled), extract buyingSignals and remainingConcerns, assess purchaseMotivation, productSuitability, and genuineUrgency (ONLY if genuinely evidenced — NEVER fabricate artificial urgency or pressure).
Recommend ONE best close from: Summary close, Alternative-choice close, Assumptive close, Clarification close, Commitment-based close, Next-step close.
Provide a natural closeScript, a clear rationale explaining why it fits this specific prospect, and a respectful followUpFallback.`,
      schema: CLOSING_SCHEMA,
      context,
      forceDeep: true,
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

// ── Cold Call Studio ───────────────────────────────────────────────────
app.post('/api/ai/cold-call', requireAuth, async (req: AuthenticatedRequest, res, next) => {
  try {
    const { targetSegment, challengeFocus, callObjective, notes = '', context = {} } = req.body as {
      targetSegment?: string;
      challengeFocus?: string;
      callObjective?: string;
      notes?: string;
      context?: IntelligenceContextPayload;
    };

    if (!targetSegment?.trim()) {
      throw new ApiError(400, 'INVALID_INPUT', 'Target prospect segment is required.');
    }

    const result = await generateStructuredJson({
      prompt: `Target Prospect Segment: ${targetSegment}\nChallenge Focus: ${challengeFocus || 'General Thaurus Guru Challenges'}\nCall Objective: ${callObjective || 'Qualify interest & book next step'}\nNotes: ${notes}`,
      taskDirective: `Design a two-way conversational cold-call playbook.
Cold calling is a dialogue, NOT a monologue. Encourage the prospect to speak early, avoid repetitive robotic openings, and craft natural Nigerian/global fintech-grade lines across:
openingLines (3 distinct options), naturalIntroduction, attentionQuestions, discoveryQuestions, productPositioning (short, value-first), conversationalTransitions, objectionPivots (3 common call pushbacks + pivots), closingQuestions, and followUpStrategy.`,
      schema: COLD_CALL_SCHEMA,
      context,
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

// ── Product Intelligence Q&A (RAG-Grounded) ────────────────────────────
app.post('/api/ai/product-qa', requireAuth, async (req: AuthenticatedRequest, res, next) => {
  try {
    const { question, categoryFilter = 'All', context = {} } = req.body as {
      question?: string;
      categoryFilter?: string;
      context?: IntelligenceContextPayload;
    };

    if (!question?.trim()) {
      throw new ApiError(400, 'INVALID_INPUT', 'Product question is required.');
    }

    const result = await generateStructuredJson({
      prompt: `Category Filter: ${categoryFilter}\nExecutive Question: ${question.trim()}`,
      taskDirective: `Answer using ONLY the Verified Company Knowledge Chunks provided in context.
- Prefer the highest documentVersion when chunks overlap.
- List exact verifiedClaims and sourceCitations (e.g., "Title (v2)").
- If two chunks conflict, list the discrepancy in detectedConflicts.
- If the chunks do not contain the required factual answer, explicitly list what is missing in missingInfoGaps and set suggestedKnowledgeGapTitle so an administrator can verify and upload the missing spec. NEVER invent unsupported prices, rules, or percentages.`,
      schema: PRODUCT_QA_SCHEMA,
      context,
      forceDeep: true,
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

// ── Prospect Analysis Engine ───────────────────────────────────────────
app.post('/api/ai/prospect-analyze', requireAuth, async (req: AuthenticatedRequest, res, next) => {
  try {
    const { conversationText, prospectName = 'Prospect', context = {} } = req.body as {
      conversationText?: string;
      prospectName?: string;
      context?: IntelligenceContextPayload;
    };

    if (!conversationText?.trim()) {
      throw new ApiError(400, 'INVALID_INPUT', 'Conversation text is required for prospect analysis.');
    }

    const result = await generateStructuredJson({
      prompt: `Prospect Name/Alias: ${prospectName}\n\nConversation Transcript:\n${conversationText.trim()}`,
      taskDirective: `Analyse this customer conversation carefully.
For every psychological or experience inference, assign a realistic confidence label ("High", "Medium", or "Low") and ground it in observable conversation evidence. Never present guesses as verified facts.
Identify buyingSignals, unansweredQuestions, missedOpportunities, recommendedNextResponse, suggestedClosingStrategy, and memoryExtractionSuggestions (1-3 concise Layer 1 insights worth remembering).`,
      schema: PROSPECT_ANALYSIS_SCHEMA,
      context,
      forceDeep: true,
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

// ── Automated Prospect Extraction from Live Chat ───────────────────────
app.post('/api/ai/extract-prospect', requireAuth, async (req: AuthenticatedRequest, res, next) => {
  try {
    const {
      conversationText,
      channel = 'WhatsApp',
      existingProspectName = '',
      context = {},
    } = req.body as {
      conversationText?: string;
      channel?: string;
      existingProspectName?: string;
      context?: IntelligenceContextPayload;
    };

    if (!conversationText?.trim()) {
      throw new ApiError(400, 'INVALID_INPUT', 'Conversation text is required to extract a prospect profile.');
    }

    const result = await generateStructuredJson({
      prompt: `Channel: ${channel}\nExisting Linked Prospect: ${existingProspectName || 'None'}\n\nLive Conversation Thread:\n${conversationText.trim()}`,
      taskDirective: `Extract structured Prospect Intelligence fields from this live conversation thread.
STRICT SEPARATION RULE:
- In verifiedNotes, record ONLY facts explicitly stated by the user/prospect (never guesses).
- In aiObservations, summarize inferred trust level, motivation, style, and confidence ratings clearly labeled as AI observations.
- If contact details (phone/WhatsApp/email/handle) are mentioned, extract them into contactDetails; otherwise return "".
- If a prospect name is not mentioned, create a clean descriptive alias (e.g. "${channel} Prospect — $50k 2-Step") rather than leaving displayName blank.
- Set suggestedFollowUpDays to 0 if converted/declined, or 1–7 days based on urgency.`,
      schema: PROSPECT_EXTRACTION_SCHEMA,
      context,
      forceDeep: false,
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

// ── Gemini Audio Transcription (Voice Input & Hands-Free Roleplay) ─────
app.post(
  '/api/ai/transcribe',
  requireAuth,
  upload.single('audio'),
  async (req: AuthenticatedRequest, res, next) => {
    try {
      const file = req.file;
      if (!file || !file.buffer || file.buffer.length === 0) {
        throw new ApiError(400, 'MISSING_AUDIO', 'Recorded audio file is required.');
      }
      const contextHint = typeof req.body?.contextHint === 'string' ? req.body.contextHint : '';
      const result = await transcribeAudio({
        audioBuffer: file.buffer,
        mimeType: file.mimetype || 'audio/webm',
        contextHint,
      });
      if (!result.transcript) {
        throw new ApiError(422, 'EMPTY_TRANSCRIPT', 'No speech detected in the recording.');
      }
      res.json(result);
    } catch (err) {
      next(err);
    }
  },
);

// ── Sales Simulation Turn & 9-Category Evaluation ──────────────────────
app.post('/api/ai/simulation/turn', requireAuth, async (req: AuthenticatedRequest, res, next) => {
  try {
    const { prospectType, difficulty, scenarioNotes = '', transcript = [], context = {} } =
      req.body as {
        prospectType?: string;
        difficulty?: string;
        scenarioNotes?: string;
        transcript?: Array<{ speaker: 'executive' | 'prospect'; text: string }>;
        context?: IntelligenceContextPayload;
      };

    if (!prospectType || !difficulty) {
      throw new ApiError(400, 'INVALID_INPUT', 'Prospect type and difficulty are required.');
    }

    const result = await generateSimulationTurn({
      prospectType,
      difficulty,
      scenarioNotes,
      transcript: Array.isArray(transcript) ? transcript : [],
      context,
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

app.post('/api/ai/simulation/score', requireAuth, async (req: AuthenticatedRequest, res, next) => {
  try {
    const { prospectType, difficulty, transcript = [], context = {} } = req.body as {
      prospectType?: string;
      difficulty?: string;
      transcript?: Array<{ speaker: 'executive' | 'prospect'; text: string }>;
      context?: IntelligenceContextPayload;
    };

    if (!Array.isArray(transcript) || transcript.length < 2) {
      throw new ApiError(
        400,
        'INSUFFICIENT_TRANSCRIPT',
        'Complete at least one exchange before scoring the simulation.',
      );
    }

    const formatted = transcript
      .map((t, i) => `[Turn ${i + 1}] ${t.speaker === 'executive' ? 'Sales Executive' : 'Prospect'}: ${t.text}`)
      .join('\n');

    const result = await generateStructuredJson({
      prompt: `Simulation Profile: ${prospectType} (${difficulty} difficulty)\n\nTranscript:\n${formatted}`,
      taskDirective: `Score the Sales Executive strictly and honestly out of 10 across all 9 categories:
opening, discovery, listening, engagement, productKnowledge, trustBuilding, objectionHandling, persuasion, closing.
Compute overallScore (average out of 10, 1 decimal).
NEVER inflate scores to flatter the executive. If they pitched too early, skipped discovery, or made unsupported product claims, penalize appropriately and explain why.
Identify strongestArea, biggestMissedOpportunity, betterAlternativeResponse (concrete rewrite of their weakest turn), measurableImprovementTarget (1 specific target for next session), and detailedFeedback.`,
      schema: SIMULATION_SCORE_SCHEMA,
      context,
      forceDeep: true,
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

// ── Adaptive Learning Layer 5 Strategy Synthesis ───────────────────────
app.post('/api/ai/learning/synthesize', requireAuth, async (req: AuthenticatedRequest, res, next) => {
  try {
    const { feedbackRecords = [], salesOutcomes = [], knowledgeGaps = [], context = {} } =
      req.body as {
        feedbackRecords?: Array<{ rating: string; feedbackType: string; comment: string }>;
        salesOutcomes?: Array<{
          outcomeType: string;
          strategyUsed: string;
          blockingObjection?: string;
          product: string;
        }>;
        knowledgeGaps?: Array<{ title: string; description: string }>;
        context?: IntelligenceContextPayload;
      };

    const result = await generateStructuredJson({
      prompt: `Accumulated Feedback (${feedbackRecords.length} records):\n${JSON.stringify(feedbackRecords.slice(0, 40))}
\nRecorded Sales Outcomes (${salesOutcomes.length} records):\n${JSON.stringify(salesOutcomes.slice(0, 40))}
\nOpen Knowledge Gaps (${knowledgeGaps.length} records):\n${JSON.stringify(knowledgeGaps.slice(0, 20))}`,
      taskDirective: `Synthesize a concrete, evidence-based Strategy Improvement Proposal (Layer 5) based strictly on the provided feedback and sales outcomes.
Explicitly distinguish correlation from proven causation. Do NOT invent sample sizes or claim model weight training.
Provide a clear title, description, evidenceSummary, proposedChange (exact instruction rule to add if approved), correlationVsCausationNote, and any recommendedKnowledgeGaps.`,
      schema: STRATEGY_PROPOSAL_SCHEMA,
      context,
      forceDeep: true,
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

// ── Knowledge Base Document Upload & URL Import ────────────────────────
app.post(
  '/api/knowledge/upload',
  requireAuth,
  upload.single('file'),
  async (req: AuthenticatedRequest, res, next) => {
    try {
      const file = req.file;
      if (!file) {
        throw new ApiError(400, 'MISSING_FILE', 'Please attach a PDF, DOCX, TXT, or CSV file.');
      }
      const title = String(req.body.title ?? file.originalname).trim();
      const parsed = await parseUploadedDocument(
        file.buffer,
        file.originalname,
        file.mimetype,
        title,
      );
      res.json({
        title,
        originalFileName: file.originalname,
        ...parsed,
      });
    } catch (err) {
      next(err);
    }
  },
);

app.post('/api/knowledge/import-url', requireAuth, async (req: AuthenticatedRequest, res, next) => {
  try {
    const { url, title = '' } = req.body as { url?: string; title?: string };
    if (!url?.trim()) {
      throw new ApiError(400, 'INVALID_URL', 'Please provide a URL to import.');
    }
    const parsed = await importFromUrl(url, title);
    res.json({
      sourceUrl: url.trim(),
      title: parsed.resolvedTitle,
      ...parsed,
    });
  } catch (err) {
    next(err);
  }
});

app.use(errorHandler);

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Thaurus Guru Sales Intelligence OS listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
